-- Kilindi District Traders Database Schema
-- Create all required tables for the system

-- Traders table - Main trader profiles
CREATE TABLE IF NOT EXISTS traders (
    id SERIAL PRIMARY KEY,
    business_name VARCHAR(255) NOT NULL,
    owner_name VARCHAR(255) NOT NULL,
    phone_number VARCHAR(20) NOT NULL UNIQUE,
    business_location VARCHAR(255),
    business_type VARCHAR(100),
    license_number VARCHAR(100) UNIQUE,
    license_expiry_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Debts table - Track trader debts
CREATE TABLE IF NOT EXISTS debts (
    id SERIAL PRIMARY KEY,
    trader_id INTEGER REFERENCES traders(id) ON DELETE CASCADE,
    amount DECIMAL(10,2) NOT NULL,
    description TEXT,
    due_date DATE,
    status VARCHAR(20) DEFAULT 'pending', -- pending, paid, overdue
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Licenses table - License payment tracking
CREATE TABLE IF NOT EXISTS licenses (
    id SERIAL PRIMARY KEY,
    trader_id INTEGER REFERENCES traders(id) ON DELETE CASCADE,
    license_type VARCHAR(100) NOT NULL,
    fee_amount DECIMAL(10,2) NOT NULL,
    issue_date DATE,
    expiry_date DATE,
    status VARCHAR(20) DEFAULT 'active', -- active, expired, renewed
    penalty_amount DECIMAL(10,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Payments table - Payment history
CREATE TABLE IF NOT EXISTS payments (
    id SERIAL PRIMARY KEY,
    trader_id INTEGER REFERENCES traders(id) ON DELETE CASCADE,
    debt_id INTEGER REFERENCES debts(id) ON DELETE SET NULL,
    license_id INTEGER REFERENCES licenses(id) ON DELETE SET NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(50), -- mpesa, airtel_money, bank, cash
    transaction_reference VARCHAR(100),
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- SMS logs table - Track sent SMS notifications
CREATE TABLE IF NOT EXISTS sms_logs (
    id SERIAL PRIMARY KEY,
    trader_id INTEGER REFERENCES traders(id) ON DELETE CASCADE,
    phone_number VARCHAR(20) NOT NULL,
    message TEXT NOT NULL,
    sms_type VARCHAR(50), -- debt_reminder, license_expiry, payment_confirmation
    status VARCHAR(20) DEFAULT 'pending', -- pending, sent, failed
    sent_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_traders_phone ON traders(phone_number);
CREATE INDEX IF NOT EXISTS idx_traders_license ON traders(license_number);
CREATE INDEX IF NOT EXISTS idx_debts_trader ON debts(trader_id);
CREATE INDEX IF NOT EXISTS idx_debts_status ON debts(status);
CREATE INDEX IF NOT EXISTS idx_licenses_trader ON licenses(trader_id);
CREATE INDEX IF NOT EXISTS idx_licenses_expiry ON licenses(expiry_date);
CREATE INDEX IF NOT EXISTS idx_payments_trader ON payments(trader_id);
CREATE INDEX IF NOT EXISTS idx_sms_logs_trader ON sms_logs(trader_id);
