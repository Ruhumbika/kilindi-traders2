"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"
import { Sidebar } from "@/components/layout/sidebar"
import { LicenseForm } from "@/components/licenses/license-form"
import { RenewalForm } from "@/components/licenses/renewal-form"
import { LicensesTable } from "@/components/licenses/licenses-table"
import { Plus, FileText, AlertTriangle, CheckCircle, Clock } from "lucide-react"
import type { License, CreateLicenseData, CreatePaymentData } from "@/lib/types"

export default function LicensesPage() {
  const [licenses, setLicenses] = useState<License[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isLicenseFormOpen, setIsLicenseFormOpen] = useState(false)
  const [isRenewalFormOpen, setIsRenewalFormOpen] = useState(false)
  const [editingLicense, setEditingLicense] = useState<License | null>(null)
  const [renewingLicense, setRenewingLicense] = useState<License | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    loadLicenses()
  }, [])

  const loadLicenses = async () => {
    try {
      const response = await fetch("/api/licenses")
      if (response.ok) {
        const data = await response.json()
        setLicenses(data)
      } else {
        toast({
          title: "Error",
          description: "Failed to load licenses",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load licenses",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleAddLicense = () => {
    setEditingLicense(null)
    setIsLicenseFormOpen(true)
  }

  const handleEditLicense = (license: License) => {
    setEditingLicense(license)
    setIsLicenseFormOpen(true)
  }

  const handleRenewLicense = (license: License) => {
    setRenewingLicense(license)
    setIsRenewalFormOpen(true)
  }

  const handleLicenseFormSubmit = async (data: CreateLicenseData) => {
    setIsSubmitting(true)
    try {
      const url = editingLicense ? `/api/licenses/${editingLicense.id}` : "/api/licenses"
      const method = editingLicense ? "PUT" : "POST"

      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        const license = await response.json()

        if (editingLicense) {
          setLicenses((prev) => prev.map((l) => (l.id === license.id ? license : l)))
          toast({
            title: "Success",
            description: "License updated successfully",
          })
        } else {
          setLicenses((prev) => [...prev, license])
          toast({
            title: "Success",
            description: "License issued successfully",
          })
        }

        setIsLicenseFormOpen(false)
        setEditingLicense(null)
      } else {
        const error = await response.json()
        toast({
          title: "Error",
          description: error.error || "Failed to save license",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save license",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleRenewalSubmit = async (paymentData: CreatePaymentData, renewalData: { expiry_date: string }) => {
    setIsSubmitting(true)
    try {
      // Record the payment
      const paymentResponse = await fetch("/api/payments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(paymentData),
      })

      if (!paymentResponse.ok) {
        throw new Error("Failed to record payment")
      }

      // Update the license with new expiry date
      const licenseResponse = await fetch(`/api/licenses/${renewingLicense!.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...renewingLicense,
          expiry_date: renewalData.expiry_date,
          status: "renewed",
        }),
      })

      if (licenseResponse.ok) {
        const updatedLicense = await licenseResponse.json()
        setLicenses((prev) => prev.map((l) => (l.id === updatedLicense.id ? updatedLicense : l)))

        toast({
          title: "Success",
          description: "License renewed successfully",
        })

        setIsRenewalFormOpen(false)
        setRenewingLicense(null)
      } else {
        throw new Error("Failed to update license")
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to renew license",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const stats = {
    total: licenses.length,
    active: licenses.filter((l) => {
      if (!l.expiry_date) return true
      return new Date(l.expiry_date) > new Date()
    }).length,
    expiring: licenses.filter((l) => {
      if (!l.expiry_date) return false
      const daysUntilExpiry = Math.ceil(
        (new Date(l.expiry_date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24),
      )
      return daysUntilExpiry <= 30 && daysUntilExpiry >= 0
    }).length,
    expired: licenses.filter((l) => {
      if (!l.expiry_date) return false
      return new Date(l.expiry_date) < new Date()
    }).length,
    totalRevenue: licenses.reduce((sum, license) => sum + license.fee_amount, 0),
  }

  if (isLoading) {
    return (
      <div className="flex h-screen">
        <Sidebar />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading licenses...</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="border-b border-border bg-card px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-card-foreground">License Management</h1>
              <p className="text-muted-foreground">Issue, track, and renew business licenses</p>
            </div>
            <div className="flex items-center gap-2">
              <Button onClick={handleAddLicense}>
                <Plus className="h-4 w-4 mr-2" />
                Issue License
              </Button>
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-auto p-6">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Licenses</CardTitle>
                  <FileText className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardDescription className="text-2xl font-bold">{stats.total}</CardDescription>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active</CardTitle>
                  <CheckCircle className="h-4 w-4 text-green-500" />
                </CardHeader>
                <CardDescription className="text-2xl font-bold text-green-600">{stats.active}</CardDescription>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Expiring Soon</CardTitle>
                  <Clock className="h-4 w-4 text-amber-500" />
                </CardHeader>
                <CardDescription className="text-2xl font-bold text-amber-600">{stats.expiring}</CardDescription>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Expired</CardTitle>
                  <AlertTriangle className="h-4 w-4 text-red-500" />
                </CardHeader>
                <CardDescription className="text-2xl font-bold text-red-600">{stats.expired}</CardDescription>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                  <FileText className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardDescription className="text-2xl font-bold">
                  TSh {stats.totalRevenue.toLocaleString()}
                </CardDescription>
              </Card>
            </div>

            {/* Licenses Table */}
            <LicensesTable licenses={licenses} onEdit={handleEditLicense} onRenew={handleRenewLicense} />
          </div>
        </main>
      </div>

      {/* Add/Edit License Dialog */}
      <Dialog open={isLicenseFormOpen} onOpenChange={setIsLicenseFormOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingLicense ? "Edit License" : "Issue New License"}</DialogTitle>
          </DialogHeader>
          <LicenseForm
            license={editingLicense || undefined}
            onSubmit={handleLicenseFormSubmit}
            onCancel={() => setIsLicenseFormOpen(false)}
            isLoading={isSubmitting}
          />
        </DialogContent>
      </Dialog>

      {/* Renewal Dialog */}
      <Dialog open={isRenewalFormOpen} onOpenChange={setIsRenewalFormOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Renew License</DialogTitle>
          </DialogHeader>
          {renewingLicense && (
            <RenewalForm
              license={renewingLicense}
              onSubmit={handleRenewalSubmit}
              onCancel={() => setIsRenewalFormOpen(false)}
              isLoading={isSubmitting}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
