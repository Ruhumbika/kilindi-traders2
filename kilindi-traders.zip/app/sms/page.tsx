"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"
import { Sidebar } from "@/components/layout/sidebar"
import { SmsForm } from "@/components/sms/sms-form"
import { BulkSmsForm } from "@/components/sms/bulk-sms-form"
import { SmsLogsTable } from "@/components/sms/sms-logs-table"
import { MessageSquare, Send, Users, CheckCircle, XCircle, Clock } from "lucide-react"
import type { SmsLog } from "@/lib/types"

export default function SmsPage() {
  const [smsLogs, setSmsLogs] = useState<SmsLog[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isSmsFormOpen, setIsSmsFormOpen] = useState(false)
  const [isBulkFormOpen, setIsBulkFormOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    loadSmsLogs()
  }, [])

  const loadSmsLogs = async () => {
    try {
      const response = await fetch("/api/sms")
      if (response.ok) {
        const data = await response.json()
        setSmsLogs(data)
      } else {
        toast({
          title: "Error",
          description: "Failed to load SMS logs",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load SMS logs",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleSendSms = async (data: {
    trader_id?: number
    phone_number: string
    message: string
    sms_type: string
  }) => {
    setIsSubmitting(true)
    try {
      const response = await fetch("/api/sms", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        const result = await response.json()

        if (result.result.success) {
          toast({
            title: "Success",
            description: "SMS sent successfully",
          })
        } else {
          toast({
            title: "Warning",
            description: `SMS queued but delivery failed: ${result.result.error}`,
            variant: "destructive",
          })
        }

        setIsSmsFormOpen(false)
        loadSmsLogs() // Refresh logs
      } else {
        const error = await response.json()
        toast({
          title: "Error",
          description: error.error || "Failed to send SMS",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send SMS",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleBulkSms = async (data: { type: string; filters?: any }) => {
    setIsSubmitting(true)
    try {
      const response = await fetch("/api/sms/bulk", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        const result = await response.json()

        toast({
          title: "Bulk SMS Completed",
          description: result.message,
        })

        setIsBulkFormOpen(false)
        loadSmsLogs() // Refresh logs
      } else {
        const error = await response.json()
        toast({
          title: "Error",
          description: error.error || "Failed to send bulk SMS",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send bulk SMS",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const stats = {
    total: smsLogs.length,
    sent: smsLogs.filter((log) => log.status === "sent").length,
    failed: smsLogs.filter((log) => log.status === "failed").length,
    pending: smsLogs.filter((log) => log.status === "pending").length,
  }

  if (isLoading) {
    return (
      <div className="flex h-screen">
        <Sidebar />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading SMS logs...</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="border-b border-border bg-card px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-card-foreground">SMS Notifications</h1>
              <p className="text-muted-foreground">Send and track SMS notifications to traders</p>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" onClick={() => setIsBulkFormOpen(true)}>
                <Users className="h-4 w-4 mr-2" />
                Bulk SMS
              </Button>
              <Button onClick={() => setIsSmsFormOpen(true)}>
                <Send className="h-4 w-4 mr-2" />
                Send SMS
              </Button>
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-auto p-6">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total SMS</CardTitle>
                  <MessageSquare className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardDescription className="text-2xl font-bold">{stats.total}</CardDescription>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Sent</CardTitle>
                  <CheckCircle className="h-4 w-4 text-green-500" />
                </CardHeader>
                <CardDescription className="text-2xl font-bold text-green-600">{stats.sent}</CardDescription>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Failed</CardTitle>
                  <XCircle className="h-4 w-4 text-red-500" />
                </CardHeader>
                <CardDescription className="text-2xl font-bold text-red-600">{stats.failed}</CardDescription>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Pending</CardTitle>
                  <Clock className="h-4 w-4 text-amber-500" />
                </CardHeader>
                <CardDescription className="text-2xl font-bold text-amber-600">{stats.pending}</CardDescription>
              </Card>
            </div>

            {/* SMS Logs Table */}
            <SmsLogsTable smsLogs={smsLogs} onRefresh={loadSmsLogs} />
          </div>
        </main>
      </div>

      {/* Send SMS Dialog */}
      <Dialog open={isSmsFormOpen} onOpenChange={setIsSmsFormOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Send SMS</DialogTitle>
          </DialogHeader>
          <SmsForm onSubmit={handleSendSms} onCancel={() => setIsSmsFormOpen(false)} isLoading={isSubmitting} />
        </DialogContent>
      </Dialog>

      {/* Bulk SMS Dialog */}
      <Dialog open={isBulkFormOpen} onOpenChange={setIsBulkFormOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Send Bulk SMS</DialogTitle>
          </DialogHeader>
          <BulkSmsForm onSubmit={handleBulkSms} onCancel={() => setIsBulkFormOpen(false)} isLoading={isSubmitting} />
        </DialogContent>
      </Dialog>
    </div>
  )
}
