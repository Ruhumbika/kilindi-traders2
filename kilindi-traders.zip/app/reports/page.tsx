"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { Sidebar } from "@/components/layout/sidebar"
import { DateRangePicker } from "@/components/reports/date-range-picker"
import { FinancialReport } from "@/components/reports/financial-report"
import { BarChart3, FileText, Users, CreditCard, MessageSquare, TrendingUp } from "lucide-react"

export default function ReportsPage() {
  const [reportType, setReportType] = useState("summary")
  const [reportData, setReportData] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [dateRange, setDateRange] = useState({
    startDate: new Date(new Date().getFullYear(), 0, 1).toISOString().split("T")[0], // Start of year
    endDate: new Date().toISOString().split("T")[0], // Today
  })
  const { toast } = useToast()

  const reportTypes = [
    { value: "summary", label: "Summary Report", icon: <BarChart3 className="h-4 w-4" /> },
    { value: "financial", label: "Financial Report", icon: <TrendingUp className="h-4 w-4" /> },
    { value: "traders", label: "Traders Report", icon: <Users className="h-4 w-4" /> },
    { value: "debts", label: "Debts Report", icon: <CreditCard className="h-4 w-4" /> },
    { value: "licenses", label: "Licenses Report", icon: <FileText className="h-4 w-4" /> },
    { value: "sms", label: "SMS Report", icon: <MessageSquare className="h-4 w-4" /> },
  ]

  useEffect(() => {
    generateReport()
  }, [])

  const generateReport = async (startDate?: string, endDate?: string) => {
    setIsLoading(true)
    try {
      const start = startDate || dateRange.startDate
      const end = endDate || dateRange.endDate

      const response = await fetch(`/api/reports?type=${reportType}&startDate=${start}&endDate=${end}`)

      if (response.ok) {
        const data = await response.json()
        setReportData(data)
      } else {
        toast({
          title: "Error",
          description: "Failed to generate report",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate report",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleDateRangeChange = (startDate: string, endDate: string) => {
    setDateRange({ startDate, endDate })
    generateReport(startDate, endDate)
  }

  const handleReportTypeChange = (type: string) => {
    setReportType(type)
    // Regenerate report with new type
    setTimeout(() => generateReport(), 100)
  }

  const handleExport = (format: "pdf" | "excel") => {
    toast({
      title: "Export Started",
      description: `Exporting report as ${format.toUpperCase()}...`,
    })
    // Mock export functionality
    setTimeout(() => {
      toast({
        title: "Export Complete",
        description: `Report exported as ${format.toUpperCase()} successfully`,
      })
    }, 2000)
  }

  const renderReportContent = () => {
    if (!reportData) return null

    switch (reportType) {
      case "financial":
        return <FinancialReport data={reportData} />
      case "summary":
        return <SummaryReport data={reportData} />
      default:
        return <GenericReport data={reportData} type={reportType} />
    }
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="border-b border-border bg-card px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-card-foreground">Reports & Analytics</h1>
              <p className="text-muted-foreground">Generate comprehensive reports and insights</p>
            </div>
            <div className="flex items-center gap-2">
              <Select value={reportType} onValueChange={handleReportTypeChange}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {reportTypes.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      <div className="flex items-center gap-2">
                        {type.icon}
                        {type.label}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-auto p-6">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* Date Range Picker */}
            <DateRangePicker onDateRangeChange={handleDateRangeChange} onExport={handleExport} isLoading={isLoading} />

            {/* Report Content */}
            {isLoading ? (
              <Card>
                <CardContent className="flex items-center justify-center py-12">
                  <div className="text-center">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
                    <p className="text-muted-foreground">Generating report...</p>
                  </div>
                </CardContent>
              </Card>
            ) : (
              renderReportContent()
            )}
          </div>
        </main>
      </div>
    </div>
  )
}

// Summary Report Component
function SummaryReport({ data }: { data: any }) {
  const formatCurrency = (amount: number) => `TSh ${amount.toLocaleString()}`

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-green-500" />
              Financial Summary
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex justify-between">
              <span>Total Revenue:</span>
              <span className="font-mono font-bold text-green-600">{formatCurrency(data.financial.totalRevenue)}</span>
            </div>
            <div className="flex justify-between">
              <span>Outstanding Debts:</span>
              <span className="font-mono text-red-600">{formatCurrency(data.financial.outstandingDebts)}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5 text-blue-500" />
              Traders Summary
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex justify-between">
              <span>Total Traders:</span>
              <span className="font-bold">{data.traders.totalTraders}</span>
            </div>
            <div className="flex justify-between">
              <span>New Registrations:</span>
              <span className="font-bold text-blue-600">{data.traders.newTraders}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-purple-500" />
              Licenses Summary
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex justify-between">
              <span>Total Licenses:</span>
              <span className="font-bold">{data.licenses.totalLicenses}</span>
            </div>
            <div className="flex justify-between">
              <span>Expiring Soon:</span>
              <span className="font-bold text-amber-600">{data.licenses.expiringLicenses}</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// Generic Report Component
function GenericReport({ data, type }: { data: any; type: string }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>{type.charAt(0).toUpperCase() + type.slice(1)} Report</CardTitle>
        <CardDescription>
          Report period: {new Date(data.period.startDate).toLocaleDateString()} -{" "}
          {new Date(data.period.endDate).toLocaleDateString()}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <pre className="text-sm bg-muted p-4 rounded-lg overflow-auto">{JSON.stringify(data, null, 2)}</pre>
      </CardContent>
    </Card>
  )
}
