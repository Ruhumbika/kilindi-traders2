"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"
import { Sidebar } from "@/components/layout/sidebar"
import { DebtForm } from "@/components/debts/debt-form"
import { PaymentForm } from "@/components/debts/payment-form"
import { DebtsTable } from "@/components/debts/debts-table"
import { Plus, CreditCard, AlertTriangle, CheckCircle, Clock } from "lucide-react"
import type { Debt, CreateDebtData, CreatePaymentData } from "@/lib/types"

export default function DebtsPage() {
  const [debts, setDebts] = useState<Debt[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isDebtFormOpen, setIsDebtFormOpen] = useState(false)
  const [isPaymentFormOpen, setIsPaymentFormOpen] = useState(false)
  const [editingDebt, setEditingDebt] = useState<Debt | null>(null)
  const [paymentDebt, setPaymentDebt] = useState<Debt | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    loadDebts()
  }, [])

  const loadDebts = async () => {
    try {
      const response = await fetch("/api/debts")
      if (response.ok) {
        const data = await response.json()
        setDebts(data)
      } else {
        toast({
          title: "Error",
          description: "Failed to load debts",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load debts",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleAddDebt = () => {
    setEditingDebt(null)
    setIsDebtFormOpen(true)
  }

  const handleEditDebt = (debt: Debt) => {
    setEditingDebt(debt)
    setIsDebtFormOpen(true)
  }

  const handleRecordPayment = (debt: Debt) => {
    setPaymentDebt(debt)
    setIsPaymentFormOpen(true)
  }

  const handleUpdateStatus = async (debt: Debt, status: Debt["status"]) => {
    try {
      const response = await fetch(`/api/debts/${debt.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ status }),
      })

      if (response.ok) {
        const updatedDebt = await response.json()
        setDebts((prev) => prev.map((d) => (d.id === debt.id ? { ...d, status } : d)))
        toast({
          title: "Success",
          description: `Debt status updated to ${status}`,
        })
      } else {
        toast({
          title: "Error",
          description: "Failed to update debt status",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update debt status",
        variant: "destructive",
      })
    }
  }

  const handleDebtFormSubmit = async (data: CreateDebtData) => {
    setIsSubmitting(true)
    try {
      const url = editingDebt ? `/api/debts/${editingDebt.id}` : "/api/debts"
      const method = editingDebt ? "PUT" : "POST"

      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        const debt = await response.json()

        if (editingDebt) {
          setDebts((prev) => prev.map((d) => (d.id === debt.id ? debt : d)))
          toast({
            title: "Success",
            description: "Debt updated successfully",
          })
        } else {
          setDebts((prev) => [...prev, debt])
          toast({
            title: "Success",
            description: "Debt added successfully",
          })
        }

        setIsDebtFormOpen(false)
        setEditingDebt(null)
      } else {
        const error = await response.json()
        toast({
          title: "Error",
          description: error.error || "Failed to save debt",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save debt",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handlePaymentFormSubmit = async (data: CreatePaymentData) => {
    setIsSubmitting(true)
    try {
      const response = await fetch("/api/payments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        const payment = await response.json()

        // Update debt status to paid if full payment
        if (paymentDebt && data.amount >= paymentDebt.amount) {
          setDebts((prev) => prev.map((d) => (d.id === paymentDebt.id ? { ...d, status: "paid" as const } : d)))
        }

        toast({
          title: "Success",
          description: "Payment recorded successfully",
        })

        setIsPaymentFormOpen(false)
        setPaymentDebt(null)
      } else {
        const error = await response.json()
        toast({
          title: "Error",
          description: error.error || "Failed to record payment",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to record payment",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const stats = {
    total: debts.length,
    totalAmount: debts.reduce((sum, debt) => sum + debt.amount, 0),
    pending: debts.filter((d) => d.status === "pending").length,
    pendingAmount: debts.filter((d) => d.status === "pending").reduce((sum, debt) => sum + debt.amount, 0),
    paid: debts.filter((d) => d.status === "paid").length,
    paidAmount: debts.filter((d) => d.status === "paid").reduce((sum, debt) => sum + debt.amount, 0),
    overdue: debts.filter((d) => d.status === "overdue").length,
    overdueAmount: debts.filter((d) => d.status === "overdue").reduce((sum, debt) => sum + debt.amount, 0),
  }

  if (isLoading) {
    return (
      <div className="flex h-screen">
        <Sidebar />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading debts...</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="border-b border-border bg-card px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-card-foreground">Debt Collection</h1>
              <p className="text-muted-foreground">Track and manage trader debts and payments</p>
            </div>
            <div className="flex items-center gap-2">
              <Button onClick={handleAddDebt}>
                <Plus className="h-4 w-4 mr-2" />
                Add Debt
              </Button>
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-auto p-6">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Debts</CardTitle>
                  <CreditCard className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardDescription className="text-2xl font-bold">{stats.total}</CardDescription>
                <p className="text-xs text-muted-foreground">TSh {stats.totalAmount.toLocaleString()}</p>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Pending</CardTitle>
                  <Clock className="h-4 w-4 text-amber-500" />
                </CardHeader>
                <CardDescription className="text-2xl font-bold text-amber-600">{stats.pending}</CardDescription>
                <p className="text-xs text-muted-foreground">TSh {stats.pendingAmount.toLocaleString()}</p>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Paid</CardTitle>
                  <CheckCircle className="h-4 w-4 text-green-500" />
                </CardHeader>
                <CardDescription className="text-2xl font-bold text-green-600">{stats.paid}</CardDescription>
                <p className="text-xs text-muted-foreground">TSh {stats.paidAmount.toLocaleString()}</p>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Overdue</CardTitle>
                  <AlertTriangle className="h-4 w-4 text-red-500" />
                </CardHeader>
                <CardDescription className="text-2xl font-bold text-red-600">{stats.overdue}</CardDescription>
                <p className="text-xs text-muted-foreground">TSh {stats.overdueAmount.toLocaleString()}</p>
              </Card>
            </div>

            {/* Debts Table */}
            <DebtsTable
              debts={debts}
              onEdit={handleEditDebt}
              onRecordPayment={handleRecordPayment}
              onUpdateStatus={handleUpdateStatus}
            />
          </div>
        </main>
      </div>

      {/* Add/Edit Debt Dialog */}
      <Dialog open={isDebtFormOpen} onOpenChange={setIsDebtFormOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingDebt ? "Edit Debt" : "Add New Debt"}</DialogTitle>
          </DialogHeader>
          <DebtForm
            debt={editingDebt || undefined}
            onSubmit={handleDebtFormSubmit}
            onCancel={() => setIsDebtFormOpen(false)}
            isLoading={isSubmitting}
          />
        </DialogContent>
      </Dialog>

      {/* Record Payment Dialog */}
      <Dialog open={isPaymentFormOpen} onOpenChange={setIsPaymentFormOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Record Payment</DialogTitle>
          </DialogHeader>
          {paymentDebt && (
            <PaymentForm
              debt={paymentDebt}
              onSubmit={handlePaymentFormSubmit}
              onCancel={() => setIsPaymentFormOpen(false)}
              isLoading={isSubmitting}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
