"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Sidebar } from "@/components/layout/sidebar"
import { Users, CreditCard, FileText, TrendingUp, AlertTriangle, CheckCircle, Calendar } from "lucide-react"
import type { DashboardStats } from "@/lib/types"

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    loadDashboardStats()
  }, [])

  const loadDashboardStats = async () => {
    try {
      const response = await fetch("/api/dashboard")
      if (response.ok) {
        const data = await response.json()
        setStats(data)
      }
    } catch (error) {
      console.error("Failed to load dashboard stats:", error)
    } finally {
      setIsLoading(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex h-screen">
        <Sidebar />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading dashboard...</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="border-b border-border bg-card px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-card-foreground">Dashboard</h1>
              <p className="text-muted-foreground">Kilindi District Traders Management System</p>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Calendar className="h-4 w-4" />
              {new Date().toLocaleDateString("en-US", {
                weekday: "long",
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-auto p-6">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* Main Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Traders</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats?.total_traders || 0}</div>
                  <p className="text-xs text-muted-foreground">Registered businesses</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">TSh {(stats?.total_revenue || 0).toLocaleString()}</div>
                  <p className="text-xs text-muted-foreground">From payments received</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Pending Debts</CardTitle>
                  <CreditCard className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">TSh {(stats?.pending_debt_amount || 0).toLocaleString()}</div>
                  <p className="text-xs text-muted-foreground">Outstanding payments</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Expiring Licenses</CardTitle>
                  <AlertTriangle className="h-4 w-4 text-amber-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-amber-600">{stats?.expiring_licenses || 0}</div>
                  <p className="text-xs text-muted-foreground">Require renewal soon</p>
                </CardContent>
              </Card>
            </div>

            {/* Debt Overview */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Paid Debts</CardTitle>
                  <CheckCircle className="h-4 w-4 text-green-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">
                    TSh {(stats?.paid_debt_amount || 0).toLocaleString()}
                  </div>
                  <p className="text-xs text-muted-foreground">Successfully collected</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Overdue Debts</CardTitle>
                  <AlertTriangle className="h-4 w-4 text-red-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-red-600">
                    TSh {(stats?.overdue_debt_amount || 0).toLocaleString()}
                  </div>
                  <p className="text-xs text-muted-foreground">Past due date</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Debts</CardTitle>
                  <FileText className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats?.total_debts || 0}</div>
                  <p className="text-xs text-muted-foreground">Debt records</p>
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>Common administrative tasks</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <a
                    href="/traders"
                    className="flex items-center gap-3 p-4 rounded-lg border border-border hover:bg-accent hover:text-accent-foreground transition-colors"
                  >
                    <Users className="h-5 w-5" />
                    <div>
                      <p className="font-medium">Manage Traders</p>
                      <p className="text-sm text-muted-foreground">Add or edit trader records</p>
                    </div>
                  </a>

                  <a
                    href="/debts"
                    className="flex items-center gap-3 p-4 rounded-lg border border-border hover:bg-accent hover:text-accent-foreground transition-colors"
                  >
                    <CreditCard className="h-5 w-5" />
                    <div>
                      <p className="font-medium">Debt Collection</p>
                      <p className="text-sm text-muted-foreground">Track and collect debts</p>
                    </div>
                  </a>

                  <a
                    href="/licenses"
                    className="flex items-center gap-3 p-4 rounded-lg border border-border hover:bg-accent hover:text-accent-foreground transition-colors"
                  >
                    <FileText className="h-5 w-5" />
                    <div>
                      <p className="font-medium">License Management</p>
                      <p className="text-sm text-muted-foreground">Renew and track licenses</p>
                    </div>
                  </a>

                  <a
                    href="/reports"
                    className="flex items-center gap-3 p-4 rounded-lg border border-border hover:bg-accent hover:text-accent-foreground transition-colors"
                  >
                    <TrendingUp className="h-5 w-5" />
                    <div>
                      <p className="font-medium">Generate Reports</p>
                      <p className="text-sm text-muted-foreground">Financial and activity reports</p>
                    </div>
                  </a>
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>System Overview</CardTitle>
                <CardDescription>Key metrics and system health</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-600 mb-2">
                      {stats
                        ? Math.round(
                            (stats.paid_debt_amount /
                              (stats.paid_debt_amount + stats.pending_debt_amount + stats.overdue_debt_amount)) *
                              100,
                          )
                        : 0}
                      %
                    </div>
                    <p className="text-sm text-muted-foreground">Debt Collection Rate</p>
                  </div>

                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-600 mb-2">
                      TSh {((stats?.total_revenue || 0) / Math.max(stats?.total_traders || 1, 1)).toLocaleString()}
                    </div>
                    <p className="text-sm text-muted-foreground">Average Revenue per Trader</p>
                  </div>

                  <div className="text-center">
                    <div className="text-3xl font-bold text-purple-600 mb-2">{stats?.expiring_licenses || 0}</div>
                    <p className="text-sm text-muted-foreground">Licenses Need Attention</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  )
}
