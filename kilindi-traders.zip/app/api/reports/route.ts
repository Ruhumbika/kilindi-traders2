// API routes for generating reports
import { NextResponse } from "next/server"
import { getTraders, getDebts, getLicenses, getPayments, getSmsLogs } from "@/lib/database"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const reportType = searchParams.get("type")
    const startDate = searchParams.get("startDate")
    const endDate = searchParams.get("endDate")

    const start = startDate ? new Date(startDate) : new Date(new Date().getFullYear(), 0, 1) // Start of year
    const end = endDate ? new Date(endDate) : new Date() // Today

    switch (reportType) {
      case "financial":
        return NextResponse.json(await generateFinancialReport(start, end))
      case "traders":
        return NextResponse.json(await generateTradersReport(start, end))
      case "debts":
        return NextResponse.json(await generateDebtsReport(start, end))
      case "licenses":
        return NextResponse.json(await generateLicensesReport(start, end))
      case "sms":
        return NextResponse.json(await generateSmsReport(start, end))
      case "summary":
        return NextResponse.json(await generateSummaryReport(start, end))
      default:
        return NextResponse.json({ error: "Invalid report type" }, { status: 400 })
    }
  } catch (error) {
    return NextResponse.json({ error: "Failed to generate report" }, { status: 500 })
  }
}

async function generateFinancialReport(startDate: Date, endDate: Date) {
  const payments = await getPayments()
  const debts = await getDebts()
  const licenses = await getLicenses()

  const filteredPayments = payments.filter((p) => {
    const paymentDate = new Date(p.payment_date)
    return paymentDate >= startDate && paymentDate <= endDate
  })

  const totalRevenue = filteredPayments.reduce((sum, payment) => sum + payment.amount, 0)
  const debtPayments = filteredPayments.filter((p) => p.debt_id).reduce((sum, payment) => sum + payment.amount, 0)
  const licensePayments = filteredPayments.filter((p) => p.license_id).reduce((sum, payment) => sum + payment.amount, 0)

  const outstandingDebts = debts
    .filter((d) => d.status === "pending" || d.status === "overdue")
    .reduce((sum, debt) => sum + debt.amount, 0)

  // Monthly breakdown
  const monthlyData = []
  const currentDate = new Date(startDate)
  while (currentDate <= endDate) {
    const monthStart = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1)
    const monthEnd = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0)

    const monthPayments = filteredPayments.filter((p) => {
      const paymentDate = new Date(p.payment_date)
      return paymentDate >= monthStart && paymentDate <= monthEnd
    })

    const monthRevenue = monthPayments.reduce((sum, payment) => sum + payment.amount, 0)

    monthlyData.push({
      month: monthStart.toISOString().slice(0, 7), // YYYY-MM format
      revenue: monthRevenue,
      debtPayments: monthPayments.filter((p) => p.debt_id).reduce((sum, payment) => sum + payment.amount, 0),
      licensePayments: monthPayments.filter((p) => p.license_id).reduce((sum, payment) => sum + payment.amount, 0),
    })

    currentDate.setMonth(currentDate.getMonth() + 1)
  }

  return {
    period: { startDate, endDate },
    summary: {
      totalRevenue,
      debtPayments,
      licensePayments,
      outstandingDebts,
      totalPayments: filteredPayments.length,
    },
    monthlyData,
    paymentMethods: getPaymentMethodBreakdown(filteredPayments),
  }
}

async function generateTradersReport(startDate: Date, endDate: Date) {
  const traders = await getTraders()
  const debts = await getDebts()
  const licenses = await getLicenses()

  const filteredTraders = traders.filter((t) => {
    const createdDate = new Date(t.created_at)
    return createdDate >= startDate && createdDate <= endDate
  })

  const businessTypeBreakdown = traders.reduce(
    (acc, trader) => {
      const type = trader.business_type || "Other"
      acc[type] = (acc[type] || 0) + 1
      return acc
    },
    {} as Record<string, number>,
  )

  return {
    period: { startDate, endDate },
    summary: {
      totalTraders: traders.length,
      newTraders: filteredTraders.length,
      tradersWithDebts: new Set(debts.map((d) => d.trader_id)).size,
      tradersWithLicenses: new Set(licenses.map((l) => l.trader_id)).size,
    },
    businessTypeBreakdown,
    newTradersMonthly: getMonthlyTraderRegistrations(filteredTraders, startDate, endDate),
  }
}

async function generateDebtsReport(startDate: Date, endDate: Date) {
  const debts = await getDebts()

  const filteredDebts = debts.filter((d) => {
    const createdDate = new Date(d.created_at)
    return createdDate >= startDate && createdDate <= endDate
  })

  const statusBreakdown = debts.reduce(
    (acc, debt) => {
      acc[debt.status] = (acc[debt.status] || 0) + 1
      return acc
    },
    {} as Record<string, number>,
  )

  const totalAmount = filteredDebts.reduce((sum, debt) => sum + debt.amount, 0)
  const paidAmount = debts.filter((d) => d.status === "paid").reduce((sum, debt) => sum + debt.amount, 0)
  const pendingAmount = debts.filter((d) => d.status === "pending").reduce((sum, debt) => sum + debt.amount, 0)
  const overdueAmount = debts.filter((d) => d.status === "overdue").reduce((sum, debt) => sum + debt.amount, 0)

  return {
    period: { startDate, endDate },
    summary: {
      totalDebts: debts.length,
      newDebts: filteredDebts.length,
      totalAmount,
      paidAmount,
      pendingAmount,
      overdueAmount,
      collectionRate: totalAmount > 0 ? (paidAmount / totalAmount) * 100 : 0,
    },
    statusBreakdown,
  }
}

async function generateLicensesReport(startDate: Date, endDate: Date) {
  const licenses = await getLicenses()

  const filteredLicenses = licenses.filter((l) => {
    const createdDate = new Date(l.created_at)
    return createdDate >= startDate && createdDate <= endDate
  })

  const typeBreakdown = licenses.reduce(
    (acc, license) => {
      acc[license.license_type] = (acc[license.license_type] || 0) + 1
      return acc
    },
    {} as Record<string, number>,
  )

  const now = new Date()
  const expiredLicenses = licenses.filter((l) => l.expiry_date && new Date(l.expiry_date) < now)
  const expiringLicenses = licenses.filter((l) => {
    if (!l.expiry_date) return false
    const expiryDate = new Date(l.expiry_date)
    const daysUntilExpiry = Math.ceil((expiryDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))
    return daysUntilExpiry <= 30 && daysUntilExpiry >= 0
  })

  return {
    period: { startDate, endDate },
    summary: {
      totalLicenses: licenses.length,
      newLicenses: filteredLicenses.length,
      expiredLicenses: expiredLicenses.length,
      expiringLicenses: expiringLicenses.length,
      totalRevenue: licenses.reduce((sum, license) => sum + license.fee_amount, 0),
    },
    typeBreakdown,
  }
}

async function generateSmsReport(startDate: Date, endDate: Date) {
  const smsLogs = await getSmsLogs()

  const filteredSms = smsLogs.filter((s) => {
    const createdDate = new Date(s.created_at)
    return createdDate >= startDate && createdDate <= endDate
  })

  const statusBreakdown = filteredSms.reduce(
    (acc, sms) => {
      acc[sms.status] = (acc[sms.status] || 0) + 1
      return acc
    },
    {} as Record<string, number>,
  )

  const typeBreakdown = filteredSms.reduce(
    (acc, sms) => {
      const type = sms.sms_type || "manual"
      acc[type] = (acc[type] || 0) + 1
      return acc
    },
    {} as Record<string, number>,
  )

  return {
    period: { startDate, endDate },
    summary: {
      totalSms: smsLogs.length,
      sentSms: filteredSms.length,
      successRate: filteredSms.length > 0 ? (statusBreakdown.sent / filteredSms.length) * 100 : 0,
      estimatedCost: filteredSms.length * 0.05, // Mock cost calculation
    },
    statusBreakdown,
    typeBreakdown,
  }
}

async function generateSummaryReport(startDate: Date, endDate: Date) {
  const [financial, traders, debts, licenses, sms] = await Promise.all([
    generateFinancialReport(startDate, endDate),
    generateTradersReport(startDate, endDate),
    generateDebtsReport(startDate, endDate),
    generateLicensesReport(startDate, endDate),
    generateSmsReport(startDate, endDate),
  ])

  return {
    period: { startDate, endDate },
    financial: financial.summary,
    traders: traders.summary,
    debts: debts.summary,
    licenses: licenses.summary,
    sms: sms.summary,
  }
}

function getPaymentMethodBreakdown(payments: any[]) {
  return payments.reduce(
    (acc, payment) => {
      const method = payment.payment_method || "unknown"
      acc[method] = (acc[method] || 0) + payment.amount
      return acc
    },
    {} as Record<string, number>,
  )
}

function getMonthlyTraderRegistrations(traders: any[], startDate: Date, endDate: Date) {
  const monthlyData = []
  const currentDate = new Date(startDate)

  while (currentDate <= endDate) {
    const monthStart = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1)
    const monthEnd = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0)

    const monthTraders = traders.filter((t) => {
      const createdDate = new Date(t.created_at)
      return createdDate >= monthStart && createdDate <= monthEnd
    })

    monthlyData.push({
      month: monthStart.toISOString().slice(0, 7),
      count: monthTraders.length,
    })

    currentDate.setMonth(currentDate.getMonth() + 1)
  }

  return monthlyData
}
