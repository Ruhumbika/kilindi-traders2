import { type NextRequest, NextResponse } from "next/server"
import { PaymentService } from "@/lib/payment-service"

export async function POST(request: NextRequest) {
  try {
    const paymentRequest = await request.json()

    // Validate required fields
    if (!paymentRequest.amount || !paymentRequest.payment_method || !paymentRequest.trader_id) {
      return NextResponse.json({ error: "Missing required payment fields" }, { status: 400 })
    }

    // Generate reference if not provided
    if (!paymentRequest.reference) {
      const type = paymentRequest.debt_id ? "debt" : "license"
      const id = paymentRequest.debt_id || paymentRequest.license_id
      paymentRequest.reference = PaymentService.generateReference(type, id)
    }

    // Process payment
    const result = await PaymentService.processPayment(paymentRequest)

    if (result.success) {
      // Mock database update - record payment
      const paymentRecord = {
        id: Date.now(),
        trader_id: paymentRequest.trader_id,
        debt_id: paymentRequest.debt_id,
        license_id: paymentRequest.license_id,
        amount: paymentRequest.amount,
        payment_method: paymentRequest.payment_method,
        transaction_id: result.transaction_id,
        reference: result.reference,
        status: "completed",
        created_at: new Date().toISOString(),
        phone_number: paymentRequest.phone_number,
        description: paymentRequest.description,
      }

      // If this is a debt payment, update debt status
      if (paymentRequest.debt_id) {
        // Mock: Update debt status to 'paid'
        console.log(`[v0] Debt ${paymentRequest.debt_id} marked as paid`)
      }

      // If this is a license payment, update license status
      if (paymentRequest.license_id) {
        // Mock: Update license status and extend expiry
        console.log(`[v0] License ${paymentRequest.license_id} renewed`)
      }

      return NextResponse.json({
        success: true,
        payment: paymentRecord,
        transaction_id: result.transaction_id,
        message: result.message,
        receipt_url: result.receipt_url,
      })
    } else {
      return NextResponse.json(
        {
          success: false,
          message: result.message,
        },
        { status: 400 },
      )
    }
  } catch (error) {
    console.error("Payment processing error:", error)
    return NextResponse.json({ error: "Payment processing failed" }, { status: 500 })
  }
}
