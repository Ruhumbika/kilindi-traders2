// API routes for payment management
import { type NextRequest, NextResponse } from "next/server"
import { createPayment, getPayments } from "@/lib/database"
import type { CreatePaymentData } from "@/lib/types"

export async function GET() {
  try {
    const payments = await getPayments()
    return NextResponse.json(payments)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch payments" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const data: CreatePaymentData = await request.json()

    // Basic validation
    if (!data.trader_id || !data.amount) {
      return NextResponse.json({ error: "Trader ID and amount are required" }, { status: 400 })
    }

    const payment = await createPayment({
      ...data,
      payment_date: new Date().toISOString(),
    })

    return NextResponse.json(payment, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: "Failed to create payment" }, { status: 500 })
  }
}
