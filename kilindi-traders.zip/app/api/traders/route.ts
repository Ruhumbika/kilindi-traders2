// API routes for trader management
import { type NextRequest, NextResponse } from "next/server"
import { createTrader, getTraders } from "@/lib/database"
import type { CreateTraderData } from "@/lib/types"

export async function GET() {
  try {
    const traders = await getTraders()
    return NextResponse.json(traders)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch traders" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const data: CreateTraderData = await request.json()

    // Basic validation
    if (!data.business_name || !data.owner_name || !data.phone_number) {
      return NextResponse.json({ error: "Business name, owner name, and phone number are required" }, { status: 400 })
    }

    const trader = await createTrader(data)
    return NextResponse.json(trader, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: "Failed to create trader" }, { status: 500 })
  }
}
