import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest, { params }: { params: { reference: string } }) {
  try {
    const { reference } = params

    // Mock receipt data - in real app, fetch from database
    const receiptData = {
      reference,
      date: new Date().toISOString(),
      district: "Kilindi District Council",
      office: "Revenue Collection Office",
      amount: 50000, // Mock amount
      payment_method: "M-Pesa",
      transaction_id: `MP${Date.now()}`,
      trader_name: "John Doe Trading",
      description: "License Renewal Fee",
    }

    // Generate simple HTML receipt
    const receiptHtml = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Payment Receipt - ${reference}</title>
          <style>
            body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 20px; }
            .receipt-details { margin: 20px 0; }
            .row { display: flex; justify-content: space-between; margin: 10px 0; }
            .total { font-weight: bold; font-size: 1.2em; border-top: 1px solid #333; padding-top: 10px; }
            .footer { text-align: center; margin-top: 30px; font-size: 0.9em; color: #666; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>KILINDI DISTRICT COUNCIL</h1>
            <h2>OFFICIAL PAYMENT RECEIPT</h2>
            <p>Revenue Collection Office</p>
          </div>
          
          <div class="receipt-details">
            <div class="row">
              <span>Receipt No:</span>
              <span><strong>${reference}</strong></span>
            </div>
            <div class="row">
              <span>Date:</span>
              <span>${new Date().toLocaleDateString()}</span>
            </div>
            <div class="row">
              <span>Trader:</span>
              <span>${receiptData.trader_name}</span>
            </div>
            <div class="row">
              <span>Description:</span>
              <span>${receiptData.description}</span>
            </div>
            <div class="row">
              <span>Payment Method:</span>
              <span>${receiptData.payment_method}</span>
            </div>
            <div class="row">
              <span>Transaction ID:</span>
              <span>${receiptData.transaction_id}</span>
            </div>
            <div class="row total">
              <span>Total Amount:</span>
              <span>TSh ${receiptData.amount.toLocaleString()}</span>
            </div>
          </div>
          
          <div class="footer">
            <p>This is an official receipt from Kilindi District Council</p>
            <p>For inquiries, contact: revenue@kilindi.go.tz</p>
          </div>
        </body>
      </html>
    `

    return new NextResponse(receiptHtml, {
      headers: {
        "Content-Type": "text/html",
      },
    })
  } catch (error) {
    console.error("Receipt generation error:", error)
    return NextResponse.json({ error: "Failed to generate receipt" }, { status: 500 })
  }
}
