// API routes for SMS operations
import { type NextRequest, NextResponse } from "next/server"
import { createSmsLog, getSmsLogs } from "@/lib/database"
import { smsService } from "@/lib/sms-service"

export async function GET() {
  try {
    const smsLogs = await getSmsLogs()
    return NextResponse.json(smsLogs)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch SMS logs" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const { trader_id, phone_number, message, sms_type } = await request.json()

    if (!phone_number || !message) {
      return NextResponse.json({ error: "Phone number and message are required" }, { status: 400 })
    }

    // Create SMS log entry
    const smsLog = await createSmsLog({
      trader_id,
      phone_number,
      message,
      sms_type,
      status: "pending",
    })

    // Send SMS
    const result = await smsService.sendSms({
      to: phone_number,
      message,
      type: sms_type,
    })

    // Update SMS log with result
    const updatedLog = await createSmsLog({
      ...smsLog,
      status: result.success ? "sent" : "failed",
      sent_at: result.success ? new Date().toISOString() : undefined,
    })

    return NextResponse.json({
      smsLog: updatedLog,
      result,
    })
  } catch (error) {
    return NextResponse.json({ error: "Failed to send SMS" }, { status: 500 })
  }
}
