// API route for bulk SMS sending
import { type NextRequest, NextResponse } from "next/server"
import { createSmsLog, getDebts, getExpiringLicenses } from "@/lib/database"
import { smsService, SMS_TEMPLATES } from "@/lib/sms-service"

export async function POST(request: NextRequest) {
  try {
    const { type, filters } = await request.json()

    let messages: Array<{
      trader_id: number
      phone_number: string
      message: string
      sms_type: string
    }> = []

    switch (type) {
      case "debt_reminders":
        const debts = await getDebts()
        const overdueDebts = debts.filter((debt) => {
          if (debt.status !== "pending") return false
          if (!debt.due_date) return false
          return new Date(debt.due_date) < new Date()
        })

        messages = overdueDebts
          .filter((debt) => debt.trader?.phone_number)
          .map((debt) => ({
            trader_id: debt.trader_id,
            phone_number: debt.trader!.phone_number,
            message: SMS_TEMPLATES.debt_reminder(
              debt.trader!.owner_name,
              debt.trader!.business_name,
              debt.amount,
              debt.due_date,
            ),
            sms_type: "debt_reminder",
          }))
        break

      case "license_expiry":
        const expiringLicenses = await getExpiringLicenses(filters?.days || 30)

        messages = expiringLicenses
          .filter((license) => license.trader?.phone_number)
          .map((license) => {
            const daysLeft = Math.ceil(
              (new Date(license.expiry_date!).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24),
            )

            return {
              trader_id: license.trader_id,
              phone_number: license.trader!.phone_number,
              message: SMS_TEMPLATES.license_expiry(
                license.trader!.owner_name,
                license.trader!.business_name,
                license.license_type,
                license.expiry_date!,
                daysLeft,
              ),
              sms_type: "license_expiry",
            }
          })
        break

      default:
        return NextResponse.json({ error: "Invalid SMS type" }, { status: 400 })
    }

    if (messages.length === 0) {
      return NextResponse.json({ message: "No messages to send", count: 0 })
    }

    // Create SMS log entries
    const smsLogs = await Promise.all(
      messages.map((msg) =>
        createSmsLog({
          trader_id: msg.trader_id,
          phone_number: msg.phone_number,
          message: msg.message,
          sms_type: msg.sms_type,
          status: "pending",
        }),
      ),
    )

    // Send bulk SMS
    const results = await smsService.sendBulkSms(
      messages.map((msg) => ({
        to: msg.phone_number,
        message: msg.message,
        type: msg.sms_type as any,
      })),
    )

    // Update SMS logs with results
    const updatedLogs = await Promise.all(
      smsLogs.map((log, index) =>
        createSmsLog({
          ...log,
          status: results[index].success ? "sent" : "failed",
          sent_at: results[index].success ? new Date().toISOString() : undefined,
        }),
      ),
    )

    const successCount = results.filter((r) => r.success).length
    const failureCount = results.length - successCount

    return NextResponse.json({
      message: `Bulk SMS completed: ${successCount} sent, ${failureCount} failed`,
      total: results.length,
      successful: successCount,
      failed: failureCount,
      results: updatedLogs,
    })
  } catch (error) {
    return NextResponse.json({ error: "Failed to send bulk SMS" }, { status: 500 })
  }
}
