// API routes for debt management
import { type NextRequest, NextResponse } from "next/server"
import { createDebt, getDebts } from "@/lib/database"
import type { CreateDebtData } from "@/lib/types"

export async function GET() {
  try {
    const debts = await getDebts()
    return NextResponse.json(debts)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch debts" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const data: CreateDebtData = await request.json()

    // Basic validation
    if (!data.trader_id || !data.amount) {
      return NextResponse.json({ error: "Trader ID and amount are required" }, { status: 400 })
    }

    const debt = await createDebt({
      ...data,
      status: "pending",
    })
    return NextResponse.json(debt, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: "Failed to create debt" }, { status: 500 })
  }
}
