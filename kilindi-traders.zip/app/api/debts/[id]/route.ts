// API routes for individual debt operations
import { type NextRequest, NextResponse } from "next/server"
import { updateDebtStatus } from "@/lib/database"

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { status } = await request.json()
    const debtId = Number.parseInt(params.id)

    if (!status || !["pending", "paid", "overdue"].includes(status)) {
      return NextResponse.json({ error: "Valid status is required" }, { status: 400 })
    }

    const debt = await updateDebtStatus(debtId, status)

    if (!debt) {
      return NextResponse.json({ error: "Debt not found" }, { status: 404 })
    }

    return NextResponse.json(debt)
  } catch (error) {
    return NextResponse.json({ error: "Failed to update debt" }, { status: 500 })
  }
}
