// API route for expiring licenses
import { NextResponse } from "next/server"
import { getExpiringLicenses } from "@/lib/database"

export async function GET() {
  try {
    const expiringLicenses = await getExpiringLicenses(30) // Next 30 days
    return NextResponse.json(expiringLicenses)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch expiring licenses" }, { status: 500 })
  }
}
