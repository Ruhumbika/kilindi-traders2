// API routes for license management
import { type NextRequest, NextResponse } from "next/server"
import { createLicense, getLicenses } from "@/lib/database"
import type { CreateLicenseData } from "@/lib/types"

export async function GET() {
  try {
    const licenses = await getLicenses()
    return NextResponse.json(licenses)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch licenses" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const data: CreateLicenseData = await request.json()

    // Basic validation
    if (!data.trader_id || !data.license_type || !data.fee_amount) {
      return NextResponse.json({ error: "Trader ID, license type, and fee amount are required" }, { status: 400 })
    }

    const license = await createLicense({
      ...data,
      status: "active",
      penalty_amount: 0,
    })

    return NextResponse.json(license, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: "Failed to create license" }, { status: 500 })
  }
}
