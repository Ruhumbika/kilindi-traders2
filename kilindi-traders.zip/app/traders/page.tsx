"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"
import { Sidebar } from "@/components/layout/sidebar"
import { TraderForm } from "@/components/traders/trader-form"
import { TradersTable } from "@/components/traders/traders-table"
import { Plus, Upload, Download } from "lucide-react"
import type { Trader, CreateTraderData } from "@/lib/types"

export default function TradersPage() {
  const [traders, setTraders] = useState<Trader[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [editingTrader, setEditingTrader] = useState<Trader | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()

  // Load traders on component mount
  useEffect(() => {
    loadTraders()
  }, [])

  const loadTraders = async () => {
    try {
      const response = await fetch("/api/traders")
      if (response.ok) {
        const data = await response.json()
        setTraders(data)
      } else {
        toast({
          title: "Error",
          description: "Failed to load traders",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load traders",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleAddTrader = () => {
    setEditingTrader(null)
    setIsFormOpen(true)
  }

  const handleEditTrader = (trader: Trader) => {
    setEditingTrader(trader)
    setIsFormOpen(true)
  }

  const handleDeleteTrader = async (trader: Trader) => {
    if (!confirm(`Are you sure you want to delete ${trader.business_name}?`)) {
      return
    }

    try {
      const response = await fetch(`/api/traders/${trader.id}`, {
        method: "DELETE",
      })

      if (response.ok) {
        setTraders((prev) => prev.filter((t) => t.id !== trader.id))
        toast({
          title: "Success",
          description: "Trader deleted successfully",
        })
      } else {
        toast({
          title: "Error",
          description: "Failed to delete trader",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete trader",
        variant: "destructive",
      })
    }
  }

  const handleFormSubmit = async (data: CreateTraderData) => {
    setIsSubmitting(true)
    try {
      const url = editingTrader ? `/api/traders/${editingTrader.id}` : "/api/traders"
      const method = editingTrader ? "PUT" : "POST"

      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        const trader = await response.json()

        if (editingTrader) {
          setTraders((prev) => prev.map((t) => (t.id === trader.id ? trader : t)))
          toast({
            title: "Success",
            description: "Trader updated successfully",
          })
        } else {
          setTraders((prev) => [...prev, trader])
          toast({
            title: "Success",
            description: "Trader added successfully",
          })
        }

        setIsFormOpen(false)
        setEditingTrader(null)
      } else {
        const error = await response.json()
        toast({
          title: "Error",
          description: error.error || "Failed to save trader",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save trader",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleViewDebts = (trader: Trader) => {
    // Navigate to debts page with trader filter
    window.location.href = `/debts?trader=${trader.id}`
  }

  const handleViewLicenses = (trader: Trader) => {
    // Navigate to licenses page with trader filter
    window.location.href = `/licenses?trader=${trader.id}`
  }

  if (isLoading) {
    return (
      <div className="flex h-screen">
        <Sidebar />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading traders...</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="border-b border-border bg-card px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-card-foreground">Trader Management</h1>
              <p className="text-muted-foreground">Manage registered traders and business information</p>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <Upload className="h-4 w-4 mr-2" />
                Import Excel
              </Button>
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
              <Button onClick={handleAddTrader}>
                <Plus className="h-4 w-4 mr-2" />
                Add Trader
              </Button>
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-auto p-6">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Total Traders</CardDescription>
                  <CardTitle className="text-2xl">{traders.length}</CardTitle>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Active Licenses</CardDescription>
                  <CardTitle className="text-2xl">
                    {
                      traders.filter((t) => t.license_expiry_date && new Date(t.license_expiry_date) > new Date())
                        .length
                    }
                  </CardTitle>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Expiring Soon</CardDescription>
                  <CardTitle className="text-2xl text-amber-600">
                    {
                      traders.filter((t) => {
                        if (!t.license_expiry_date) return false
                        const expiry = new Date(t.license_expiry_date)
                        const today = new Date()
                        const daysUntilExpiry = Math.ceil((expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
                        return daysUntilExpiry <= 30 && daysUntilExpiry >= 0
                      }).length
                    }
                  </CardTitle>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Expired Licenses</CardDescription>
                  <CardTitle className="text-2xl text-destructive">
                    {
                      traders.filter((t) => t.license_expiry_date && new Date(t.license_expiry_date) < new Date())
                        .length
                    }
                  </CardTitle>
                </CardHeader>
              </Card>
            </div>

            {/* Traders Table */}
            <TradersTable
              traders={traders}
              onEdit={handleEditTrader}
              onDelete={handleDeleteTrader}
              onViewDebts={handleViewDebts}
              onViewLicenses={handleViewLicenses}
            />
          </div>
        </main>
      </div>

      {/* Add/Edit Trader Dialog */}
      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingTrader ? "Edit Trader" : "Add New Trader"}</DialogTitle>
          </DialogHeader>
          <TraderForm
            trader={editingTrader || undefined}
            onSubmit={handleFormSubmit}
            onCancel={() => setIsFormOpen(false)}
            isLoading={isSubmitting}
          />
        </DialogContent>
      </Dialog>
    </div>
  )
}
