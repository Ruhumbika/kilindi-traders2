"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, MoreHorizontal, Edit, RefreshCw, AlertTriangle, CheckCircle, Clock } from "lucide-react"
import type { License } from "@/lib/types"

interface LicensesTableProps {
  licenses: License[]
  onEdit: (license: License) => void
  onRenew: (license: License) => void
}

export function LicensesTable({ licenses, onEdit, onRenew }: LicensesTableProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [typeFilter, setTypeFilter] = useState<string>("all")

  const filteredLicenses = licenses.filter((license) => {
    const matchesSearch =
      license.trader?.business_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      license.trader?.owner_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      license.license_type.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === "all" || license.status === statusFilter
    const matchesType = typeFilter === "all" || license.license_type === typeFilter

    return matchesSearch && matchesStatus && matchesType
  })

  const getStatusInfo = (license: License) => {
    if (!license.expiry_date) return { status: "No Expiry", variant: "outline" as const, icon: null }

    const expiryDate = new Date(license.expiry_date)
    const today = new Date()
    const daysUntilExpiry = Math.ceil((expiryDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))

    if (daysUntilExpiry < 0) {
      return { status: "Expired", variant: "destructive" as const, icon: <AlertTriangle className="h-3 w-3" /> }
    } else if (daysUntilExpiry <= 7) {
      return {
        status: "Expires This Week",
        variant: "destructive" as const,
        icon: <AlertTriangle className="h-3 w-3" />,
      }
    } else if (daysUntilExpiry <= 30) {
      return { status: "Expiring Soon", variant: "default" as const, icon: <Clock className="h-3 w-3" /> }
    } else {
      return { status: "Active", variant: "secondary" as const, icon: <CheckCircle className="h-3 w-3" /> }
    }
  }

  const uniqueTypes = Array.from(new Set(licenses.map((l) => l.license_type))).sort()

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>License Management</CardTitle>
            <CardDescription>Track business licenses, renewals, and expiry dates</CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                {uniqueTypes.map((type) => (
                  <SelectItem key={type} value={type}>
                    {type}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="expired">Expired</SelectItem>
                <SelectItem value="renewed">Renewed</SelectItem>
              </SelectContent>
            </Select>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search licenses..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-64"
              />
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Trader</TableHead>
                <TableHead>License Type</TableHead>
                <TableHead>Fee Amount</TableHead>
                <TableHead>Issue Date</TableHead>
                <TableHead>Expiry Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="w-[70px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredLicenses.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                    {searchTerm || statusFilter !== "all" || typeFilter !== "all"
                      ? "No licenses found matching your criteria."
                      : "No licenses issued yet."}
                  </TableCell>
                </TableRow>
              ) : (
                filteredLicenses.map((license) => {
                  const statusInfo = getStatusInfo(license)
                  const isExpired = license.expiry_date && new Date(license.expiry_date) < new Date()

                  return (
                    <TableRow key={license.id} className={isExpired ? "bg-red-50 dark:bg-red-950/20" : ""}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{license.trader?.business_name || "Unknown Business"}</p>
                          <p className="text-sm text-muted-foreground">{license.trader?.owner_name}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{license.license_type}</Badge>
                      </TableCell>
                      <TableCell className="font-mono">TSh {license.fee_amount.toLocaleString()}</TableCell>
                      <TableCell className="text-sm">
                        {license.issue_date ? new Date(license.issue_date).toLocaleDateString() : "Not set"}
                      </TableCell>
                      <TableCell className="text-sm">
                        {license.expiry_date ? (
                          <div className={isExpired ? "text-red-600 font-medium" : ""}>
                            {new Date(license.expiry_date).toLocaleDateString()}
                          </div>
                        ) : (
                          <span className="text-muted-foreground">No expiry</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge variant={statusInfo.variant} className="flex items-center gap-1 w-fit">
                          {statusInfo.icon}
                          {statusInfo.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => onEdit(license)}>
                              <Edit className="h-4 w-4 mr-2" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => onRenew(license)}>
                              <RefreshCw className="h-4 w-4 mr-2" />
                              Renew License
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  )
                })
              )}
            </TableBody>
          </Table>
        </div>

        {filteredLicenses.length > 0 && (
          <div className="flex items-center justify-between pt-4">
            <p className="text-sm text-muted-foreground">
              Showing {filteredLicenses.length} of {licenses.length} licenses
            </p>
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span>
                Total Fees: TSh{" "}
                {filteredLicenses.reduce((sum, license) => sum + license.fee_amount, 0).toLocaleString()}
              </span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
