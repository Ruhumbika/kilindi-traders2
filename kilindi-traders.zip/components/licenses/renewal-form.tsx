"use client"

import type { ReactElement } from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { License, CreatePaymentData } from "@/lib/types"

interface RenewalFormProps {
  license: License
  onSubmit: (paymentData: CreatePaymentData, renewalData: { expiry_date: string }) => Promise<void>
  onCancel: () => void
  isLoading?: boolean
}

export function RenewalForm({ license, onSubmit, onCancel, isLoading }: RenewalFormProps): ReactElement {
  const [renewalData, setRenewalData] = useState({
    payment_amount: license.fee_amount,
    penalty_amount: 0,
    new_expiry_date: "",
  })

  // Calculate penalty for late renewal
  const calculatePenalty = () => {
    if (!license.expiry_date) return 0
    const expiryDate = new Date(license.expiry_date)
    const today = new Date()
    const daysOverdue = Math.ceil((today.getTime() - expiryDate.getTime()) / (1000 * 60 * 60 * 24))

    if (daysOverdue > 0) {
      // 10% penalty for first 30 days, then 20%
      const penaltyRate = daysOverdue <= 30 ? 0.1 : 0.2
      return license.fee_amount * penaltyRate
    }
    return 0
  }

  const penalty = calculatePenalty()
  const totalAmount = license.fee_amount + penalty

  // Auto-set new expiry date (1 year from today or from original expiry, whichever is later)
  const React = require("react")
  React.useEffect(() => {
    const today = new Date()
    const originalExpiry = license.expiry_date ? new Date(license.expiry_date) : today
    const baseDate = originalExpiry > today ? originalExpiry : today
    const newExpiry = new Date(baseDate)
    newExpiry.setFullYear(newExpiry.getFullYear() + 1)

    setRenewalData((prev) => ({
      ...prev,
      penalty_amount: penalty,
      payment_amount: totalAmount,
      new_expiry_date: newExpiry.toISOString().split("T")[0],
    }))
  }, [license, penalty, totalAmount])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    const paymentData: CreatePaymentData = {
      trader_id: license.trader_id,
      license_id: license.id,
      amount: renewalData.payment_amount,
      notes: `License renewal for ${license.license_type}${penalty > 0 ? ` (includes penalty: TSh ${penalty.toLocaleString()})` : ""}`,
    }

    const renewalInfo = {
      expiry_date: renewalData.new_expiry_date,
    }

    await onSubmit(paymentData, renewalInfo)
  }

  const isExpired = license.expiry_date && new Date(license.expiry_date) < new Date()
  const daysUntilExpiry = license.expiry_date
    ? Math.ceil((new Date(license.expiry_date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))
    : 0

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Renew License</CardTitle>
        <CardDescription>Renew license for {license.trader?.business_name || "Unknown Trader"}</CardDescription>
      </CardHeader>
      <CardContent>
        {/* License Information */}
        <div className="mb-6 p-4 bg-muted rounded-lg space-y-3">
          <div className="flex justify-between items-center">
            <span className="font-medium">License Type:</span>
            <span>{license.license_type}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="font-medium">Current Status:</span>
            <Badge variant={isExpired ? "destructive" : daysUntilExpiry <= 30 ? "default" : "secondary"}>
              {isExpired ? "Expired" : daysUntilExpiry <= 30 ? "Expiring Soon" : "Active"}
            </Badge>
          </div>
          <div className="flex justify-between items-center">
            <span className="font-medium">Current Expiry:</span>
            <span className={isExpired ? "text-red-600 font-medium" : ""}>
              {license.expiry_date ? new Date(license.expiry_date).toLocaleDateString() : "Not set"}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="font-medium">Base Fee:</span>
            <span>TSh {license.fee_amount.toLocaleString()}</span>
          </div>
          {penalty > 0 && (
            <div className="flex justify-between items-center text-red-600">
              <span className="font-medium">Late Penalty:</span>
              <span>TSh {penalty.toLocaleString()}</span>
            </div>
          )}
          <div className="flex justify-between items-center border-t pt-2">
            <span className="font-bold">Total Amount:</span>
            <span className="font-bold text-lg">TSh {totalAmount.toLocaleString()}</span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="payment_amount">Payment Amount (TSh) *</Label>
              <Input
                id="payment_amount"
                type="number"
                min="0"
                step="0.01"
                value={renewalData.payment_amount}
                onChange={(e) =>
                  setRenewalData((prev) => ({ ...prev, payment_amount: Number.parseFloat(e.target.value) || 0 }))
                }
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="new_expiry_date">New Expiry Date *</Label>
              <Input
                id="new_expiry_date"
                type="date"
                value={renewalData.new_expiry_date}
                onChange={(e) => setRenewalData((prev) => ({ ...prev, new_expiry_date: e.target.value }))}
                required
              />
            </div>
          </div>

          {penalty > 0 && (
            <div className="p-4 bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded-lg">
              <h4 className="font-medium text-red-800 dark:text-red-200 mb-2">Late Renewal Penalty</h4>
              <p className="text-sm text-red-700 dark:text-red-300">
                This license expired{" "}
                {Math.ceil((new Date().getTime() - new Date(license.expiry_date!).getTime()) / (1000 * 60 * 60 * 24))}{" "}
                days ago. A penalty of TSh {penalty.toLocaleString()} (
                {penalty <= license.fee_amount * 0.1 ? "10%" : "20%"}) has been applied.
              </p>
            </div>
          )}

          <div className="flex gap-4 pt-4">
            <Button type="submit" disabled={isLoading} className="flex-1">
              {isLoading ? "Processing..." : `Renew License (TSh ${totalAmount.toLocaleString()})`}
            </Button>
            <Button type="button" variant="outline" onClick={onCancel} className="flex-1 bg-transparent">
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
