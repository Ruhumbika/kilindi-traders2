"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { CreateLicenseData, License, Trader } from "@/lib/types"

interface LicenseFormProps {
  license?: License
  onSubmit: (data: CreateLicenseData) => Promise<void>
  onCancel: () => void
  isLoading?: boolean
}

const licenseTypes = [
  "Business License",
  "Trading License",
  "Food Handler's License",
  "Liquor License",
  "Transport License",
  "Construction License",
  "Manufacturing License",
  "Service Provider License",
  "Import/Export License",
  "Other",
]

export function LicenseForm({ license, onSubmit, onCancel, isLoading }: LicenseFormProps) {
  const [traders, setTraders] = useState<Trader[]>([])
  const [formData, setFormData] = useState<CreateLicenseData>({
    trader_id: license?.trader_id || 0,
    license_type: license?.license_type || "",
    fee_amount: license?.fee_amount || 0,
    issue_date: license?.issue_date || "",
    expiry_date: license?.expiry_date || "",
  })

  useEffect(() => {
    loadTraders()
  }, [])

  const loadTraders = async () => {
    try {
      const response = await fetch("/api/traders")
      if (response.ok) {
        const data = await response.json()
        setTraders(data)
      }
    } catch (error) {
      console.error("Failed to load traders:", error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    await onSubmit(formData)
  }

  const handleChange = (field: keyof CreateLicenseData, value: string | number) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  // Auto-calculate expiry date (1 year from issue date)
  const handleIssueDateChange = (issueDate: string) => {
    handleChange("issue_date", issueDate)
    if (issueDate) {
      const issue = new Date(issueDate)
      const expiry = new Date(issue)
      expiry.setFullYear(expiry.getFullYear() + 1)
      handleChange("expiry_date", expiry.toISOString().split("T")[0])
    }
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>{license ? "Edit License" : "Issue New License"}</CardTitle>
        <CardDescription>
          {license ? "Update license information" : "Issue a new business license for a trader"}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="trader_id">Trader *</Label>
              <Select
                value={formData.trader_id.toString()}
                onValueChange={(value) => handleChange("trader_id", Number.parseInt(value))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a trader" />
                </SelectTrigger>
                <SelectContent>
                  {traders.map((trader) => (
                    <SelectItem key={trader.id} value={trader.id.toString()}>
                      {trader.business_name} - {trader.owner_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="license_type">License Type *</Label>
              <Select value={formData.license_type} onValueChange={(value) => handleChange("license_type", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select license type" />
                </SelectTrigger>
                <SelectContent>
                  {licenseTypes.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="fee_amount">License Fee (TSh) *</Label>
              <Input
                id="fee_amount"
                type="number"
                min="0"
                step="0.01"
                value={formData.fee_amount}
                onChange={(e) => handleChange("fee_amount", Number.parseFloat(e.target.value) || 0)}
                placeholder="Enter license fee"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="issue_date">Issue Date *</Label>
              <Input
                id="issue_date"
                type="date"
                value={formData.issue_date}
                onChange={(e) => handleIssueDateChange(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="expiry_date">Expiry Date *</Label>
              <Input
                id="expiry_date"
                type="date"
                value={formData.expiry_date}
                onChange={(e) => handleChange("expiry_date", e.target.value)}
                required
              />
              <p className="text-xs text-muted-foreground">
                Automatically set to 1 year from issue date, but can be modified
              </p>
            </div>
          </div>

          <div className="flex gap-4 pt-4">
            <Button type="submit" disabled={isLoading} className="flex-1">
              {isLoading ? "Saving..." : license ? "Update License" : "Issue License"}
            </Button>
            <Button type="button" variant="outline" onClick={onCancel} className="flex-1 bg-transparent">
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
