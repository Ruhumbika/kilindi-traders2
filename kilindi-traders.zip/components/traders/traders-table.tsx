"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Search, MoreHorizontal, Edit, Trash2, Phone, FileText } from "lucide-react"
import type { Trader } from "@/lib/types"

interface TradersTableProps {
  traders: Trader[]
  onEdit: (trader: Trader) => void
  onDelete: (trader: Trader) => void
  onViewDebts: (trader: Trader) => void
  onViewLicenses: (trader: Trader) => void
}

export function TradersTable({ traders, onEdit, onDelete, onViewDebts, onViewLicenses }: TradersTableProps) {
  const [searchTerm, setSearchTerm] = useState("")

  const filteredTraders = traders.filter(
    (trader) =>
      trader.business_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      trader.owner_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      trader.phone_number.includes(searchTerm) ||
      trader.business_type?.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const isLicenseExpiring = (expiryDate?: string) => {
    if (!expiryDate) return false
    const expiry = new Date(expiryDate)
    const today = new Date()
    const daysUntilExpiry = Math.ceil((expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
    return daysUntilExpiry <= 30 && daysUntilExpiry >= 0
  }

  const isLicenseExpired = (expiryDate?: string) => {
    if (!expiryDate) return false
    const expiry = new Date(expiryDate)
    const today = new Date()
    return expiry < today
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Registered Traders</CardTitle>
            <CardDescription>Manage trader records and business information</CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search traders..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-64"
              />
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Business Name</TableHead>
                <TableHead>Owner</TableHead>
                <TableHead>Phone</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>License Status</TableHead>
                <TableHead>Location</TableHead>
                <TableHead className="w-[70px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTraders.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                    {searchTerm ? "No traders found matching your search." : "No traders registered yet."}
                  </TableCell>
                </TableRow>
              ) : (
                filteredTraders.map((trader) => (
                  <TableRow key={trader.id}>
                    <TableCell className="font-medium">{trader.business_name}</TableCell>
                    <TableCell>{trader.owner_name}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Phone className="h-3 w-3 text-muted-foreground" />
                        {trader.phone_number}
                      </div>
                    </TableCell>
                    <TableCell>
                      {trader.business_type && <Badge variant="secondary">{trader.business_type}</Badge>}
                    </TableCell>
                    <TableCell>
                      {trader.license_expiry_date ? (
                        <div className="flex flex-col gap-1">
                          <Badge
                            variant={
                              isLicenseExpired(trader.license_expiry_date)
                                ? "destructive"
                                : isLicenseExpiring(trader.license_expiry_date)
                                  ? "default"
                                  : "secondary"
                            }
                          >
                            {isLicenseExpired(trader.license_expiry_date)
                              ? "Expired"
                              : isLicenseExpiring(trader.license_expiry_date)
                                ? "Expiring Soon"
                                : "Active"}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {new Date(trader.license_expiry_date).toLocaleDateString()}
                          </span>
                        </div>
                      ) : (
                        <Badge variant="outline">No License</Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {trader.business_location || "Not specified"}
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => onEdit(trader)}>
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => onViewDebts(trader)}>
                            <FileText className="h-4 w-4 mr-2" />
                            View Debts
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => onViewLicenses(trader)}>
                            <FileText className="h-4 w-4 mr-2" />
                            View Licenses
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => onDelete(trader)} className="text-destructive">
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>

        {filteredTraders.length > 0 && (
          <div className="flex items-center justify-between pt-4">
            <p className="text-sm text-muted-foreground">
              Showing {filteredTraders.length} of {traders.length} traders
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
