"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { CreateTraderData, Trader } from "@/lib/types"

interface TraderFormProps {
  trader?: Trader
  onSubmit: (data: CreateTraderData) => Promise<void>
  onCancel: () => void
  isLoading?: boolean
}

const businessTypes = [
  "Retail Shop",
  "Restaurant",
  "Hardware Store",
  "Pharmacy",
  "Electronics",
  "Clothing Store",
  "Grocery Store",
  "Service Provider",
  "Manufacturing",
  "Other",
]

export function TraderForm({ trader, onSubmit, onCancel, isLoading }: TraderFormProps) {
  const [formData, setFormData] = useState<CreateTraderData>({
    business_name: trader?.business_name || "",
    owner_name: trader?.owner_name || "",
    phone_number: trader?.phone_number || "",
    business_location: trader?.business_location || "",
    business_type: trader?.business_type || "",
    license_number: trader?.license_number || "",
    license_expiry_date: trader?.license_expiry_date || "",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    await onSubmit(formData)
  }

  const handleChange = (field: keyof CreateTraderData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>{trader ? "Edit Trader" : "Add New Trader"}</CardTitle>
        <CardDescription>
          {trader ? "Update trader information" : "Enter trader details to register a new business"}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="business_name">Business Name *</Label>
              <Input
                id="business_name"
                value={formData.business_name}
                onChange={(e) => handleChange("business_name", e.target.value)}
                placeholder="Enter business name"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="owner_name">Owner Name *</Label>
              <Input
                id="owner_name"
                value={formData.owner_name}
                onChange={(e) => handleChange("owner_name", e.target.value)}
                placeholder="Enter owner's full name"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone_number">Phone Number *</Label>
              <Input
                id="phone_number"
                value={formData.phone_number}
                onChange={(e) => handleChange("phone_number", e.target.value)}
                placeholder="+255 XXX XXX XXX"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="business_location">Business Location</Label>
              <Input
                id="business_location"
                value={formData.business_location}
                onChange={(e) => handleChange("business_location", e.target.value)}
                placeholder="Enter business address"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="business_type">Business Type</Label>
              <Select value={formData.business_type} onValueChange={(value) => handleChange("business_type", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select business type" />
                </SelectTrigger>
                <SelectContent>
                  {businessTypes.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="license_number">License Number</Label>
              <Input
                id="license_number"
                value={formData.license_number}
                onChange={(e) => handleChange("license_number", e.target.value)}
                placeholder="Enter license number"
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="license_expiry_date">License Expiry Date</Label>
              <Input
                id="license_expiry_date"
                type="date"
                value={formData.license_expiry_date}
                onChange={(e) => handleChange("license_expiry_date", e.target.value)}
              />
            </div>
          </div>

          <div className="flex gap-4 pt-4">
            <Button type="submit" disabled={isLoading} className="flex-1">
              {isLoading ? "Saving..." : trader ? "Update Trader" : "Add Trader"}
            </Button>
            <Button type="button" variant="outline" onClick={onCancel} className="flex-1 bg-transparent">
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
