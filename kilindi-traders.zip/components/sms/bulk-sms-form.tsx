"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { AlertTriangle, FileText } from "lucide-react"

interface BulkSmsFormProps {
  onSubmit: (data: { type: string; filters?: any }) => Promise<void>
  onCancel: () => void
  isLoading?: boolean
}

export function BulkSmsForm({ onSubmit, onCancel, isLoading }: BulkSmsFormProps) {
  const [formData, setFormData] = useState({
    type: "",
    days: 30,
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    await onSubmit({
      type: formData.type,
      filters: formData.type === "license_expiry" ? { days: formData.days } : undefined,
    })
  }

  const smsTypes = [
    {
      value: "debt_reminders",
      label: "Debt Reminders",
      description: "Send reminders to traders with overdue debts",
      icon: <AlertTriangle className="h-5 w-5 text-red-500" />,
    },
    {
      value: "license_expiry",
      label: "License Expiry Alerts",
      description: "Notify traders about expiring licenses",
      icon: <FileText className="h-5 w-5 text-amber-500" />,
    },
  ]

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Send Bulk SMS</CardTitle>
        <CardDescription>Send automated SMS notifications to multiple traders</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>SMS Campaign Type *</Label>
              <div className="grid gap-3">
                {smsTypes.map((type) => (
                  <div
                    key={type.value}
                    className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                      formData.type === type.value
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/50"
                    }`}
                    onClick={() => setFormData((prev) => ({ ...prev, type: type.value }))}
                  >
                    <div className="flex items-start gap-3">
                      {type.icon}
                      <div className="flex-1">
                        <h4 className="font-medium">{type.label}</h4>
                        <p className="text-sm text-muted-foreground">{type.description}</p>
                      </div>
                      <div className="flex items-center">
                        <input
                          type="radio"
                          name="sms_type"
                          value={type.value}
                          checked={formData.type === type.value}
                          onChange={() => setFormData((prev) => ({ ...prev, type: type.value }))}
                          className="h-4 w-4"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {formData.type === "license_expiry" && (
              <div className="space-y-2">
                <Label htmlFor="days">Days Before Expiry</Label>
                <Select
                  value={formData.days.toString()}
                  onValueChange={(value) => setFormData((prev) => ({ ...prev, days: Number.parseInt(value) }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7">7 days</SelectItem>
                    <SelectItem value="15">15 days</SelectItem>
                    <SelectItem value="30">30 days</SelectItem>
                    <SelectItem value="60">60 days</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">
                  Send alerts to traders whose licenses expire within this timeframe
                </p>
              </div>
            )}
          </div>

          <div className="p-4 bg-muted rounded-lg">
            <div className="flex items-start gap-2">
              <AlertTriangle className="h-4 w-4 text-amber-500 mt-0.5" />
              <div className="text-sm">
                <p className="font-medium">Important:</p>
                <p className="text-muted-foreground">
                  Bulk SMS will be sent to all eligible traders. Please review the campaign type carefully before
                  sending. SMS charges will apply for each message sent.
                </p>
              </div>
            </div>
          </div>

          <div className="flex gap-4 pt-4">
            <Button type="submit" disabled={isLoading || !formData.type} className="flex-1">
              {isLoading ? "Sending..." : "Send Bulk SMS"}
            </Button>
            <Button type="button" variant="outline" onClick={onCancel} className="flex-1 bg-transparent">
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
