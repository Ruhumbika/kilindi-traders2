"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import type { Trader } from "@/lib/types"

interface SmsFormProps {
  onSubmit: (data: {
    trader_id?: number
    phone_number: string
    message: string
    sms_type: string
  }) => Promise<void>
  onCancel: () => void
  isLoading?: boolean
}

export function SmsForm({ onSubmit, onCancel, isLoading }: SmsFormProps) {
  const [traders, setTraders] = useState<Trader[]>([])
  const [formData, setFormData] = useState({
    trader_id: "",
    phone_number: "",
    message: "",
    sms_type: "manual",
  })

  useEffect(() => {
    loadTraders()
  }, [])

  const loadTraders = async () => {
    try {
      const response = await fetch("/api/traders")
      if (response.ok) {
        const data = await response.json()
        setTraders(data)
      }
    } catch (error) {
      console.error("Failed to load traders:", error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    await onSubmit({
      trader_id: formData.trader_id ? Number.parseInt(formData.trader_id) : undefined,
      phone_number: formData.phone_number,
      message: formData.message,
      sms_type: formData.sms_type,
    })
  }

  const handleTraderSelect = (traderId: string) => {
    const trader = traders.find((t) => t.id.toString() === traderId)
    setFormData((prev) => ({
      ...prev,
      trader_id: traderId,
      phone_number: trader?.phone_number || "",
    }))
  }

  const messageLength = formData.message.length
  const maxLength = 160
  const smsCount = Math.ceil(messageLength / maxLength)

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Send SMS</CardTitle>
        <CardDescription>Send SMS notification to a trader</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="trader_id">Select Trader (Optional)</Label>
              <Select value={formData.trader_id} onValueChange={handleTraderSelect}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a trader or enter phone manually" />
                </SelectTrigger>
                <SelectContent>
                  {traders.map((trader) => (
                    <SelectItem key={trader.id} value={trader.id.toString()}>
                      {trader.business_name} - {trader.owner_name} ({trader.phone_number})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone_number">Phone Number *</Label>
              <Input
                id="phone_number"
                value={formData.phone_number}
                onChange={(e) => setFormData((prev) => ({ ...prev, phone_number: e.target.value }))}
                placeholder="+255 XXX XXX XXX"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="sms_type">Message Type</Label>
              <Select
                value={formData.sms_type}
                onValueChange={(value) => setFormData((prev) => ({ ...prev, sms_type: value }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="manual">Manual Message</SelectItem>
                  <SelectItem value="debt_reminder">Debt Reminder</SelectItem>
                  <SelectItem value="license_expiry">License Expiry</SelectItem>
                  <SelectItem value="payment_confirmation">Payment Confirmation</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2 md:col-span-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="message">Message *</Label>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span>
                    {messageLength}/{maxLength}
                  </span>
                  {smsCount > 1 && <Badge variant="outline">{smsCount} SMS</Badge>}
                </div>
              </div>
              <Textarea
                id="message"
                value={formData.message}
                onChange={(e) => setFormData((prev) => ({ ...prev, message: e.target.value }))}
                placeholder="Enter your message here..."
                rows={4}
                required
              />
              <p className="text-xs text-muted-foreground">
                Messages longer than 160 characters will be sent as multiple SMS
              </p>
            </div>
          </div>

          <div className="flex gap-4 pt-4">
            <Button
              type="submit"
              disabled={isLoading || !formData.phone_number || !formData.message}
              className="flex-1"
            >
              {isLoading ? "Sending..." : "Send SMS"}
            </Button>
            <Button type="button" variant="outline" onClick={onCancel} className="flex-1 bg-transparent">
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
