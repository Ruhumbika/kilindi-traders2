"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, CheckCircle, XCircle, Clock, RefreshCw } from "lucide-react"
import type { SmsLog } from "@/lib/types"

interface SmsLogsTableProps {
  smsLogs: SmsLog[]
  onRefresh: () => void
}

export function SmsLogsTable({ smsLogs, onRefresh }: SmsLogsTableProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [typeFilter, setTypeFilter] = useState<string>("all")

  const filteredLogs = smsLogs.filter((log) => {
    const matchesSearch =
      log.trader?.business_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.trader?.owner_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.phone_number.includes(searchTerm) ||
      log.message.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === "all" || log.status === statusFilter
    const matchesType = typeFilter === "all" || log.sms_type === typeFilter

    return matchesSearch && matchesStatus && matchesType
  })

  const getStatusIcon = (status: SmsLog["status"]) => {
    switch (status) {
      case "sent":
        return <CheckCircle className="h-3 w-3" />
      case "failed":
        return <XCircle className="h-3 w-3" />
      default:
        return <Clock className="h-3 w-3" />
    }
  }

  const getStatusVariant = (status: SmsLog["status"]) => {
    switch (status) {
      case "sent":
        return "default" as const
      case "failed":
        return "destructive" as const
      default:
        return "secondary" as const
    }
  }

  const uniqueTypes = Array.from(new Set(smsLogs.map((log) => log.sms_type).filter(Boolean))).sort()

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>SMS Logs</CardTitle>
            <CardDescription>Track sent SMS notifications and delivery status</CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={onRefresh}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              {uniqueTypes.map((type) => (
                <SelectItem key={type} value={type}>
                  {type?.replace("_", " ").replace(/\b\w/g, (l) => l.toUpperCase())}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="sent">Sent</SelectItem>
              <SelectItem value="failed">Failed</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
            </SelectContent>
          </Select>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Search SMS logs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Recipient</TableHead>
                <TableHead>Phone</TableHead>
                <TableHead>Message</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Sent At</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredLogs.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                    {searchTerm || statusFilter !== "all" || typeFilter !== "all"
                      ? "No SMS logs found matching your criteria."
                      : "No SMS messages sent yet."}
                  </TableCell>
                </TableRow>
              ) : (
                filteredLogs.map((log) => (
                  <TableRow key={log.id}>
                    <TableCell>
                      {log.trader ? (
                        <div>
                          <p className="font-medium">{log.trader.business_name}</p>
                          <p className="text-sm text-muted-foreground">{log.trader.owner_name}</p>
                        </div>
                      ) : (
                        <span className="text-muted-foreground">Unknown Trader</span>
                      )}
                    </TableCell>
                    <TableCell className="font-mono">{log.phone_number}</TableCell>
                    <TableCell className="max-w-xs">
                      <p className="truncate" title={log.message}>
                        {log.message}
                      </p>
                    </TableCell>
                    <TableCell>
                      {log.sms_type && (
                        <Badge variant="outline">
                          {log.sms_type.replace("_", " ").replace(/\b\w/g, (l) => l.toUpperCase())}
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge variant={getStatusVariant(log.status)} className="flex items-center gap-1 w-fit">
                        {getStatusIcon(log.status)}
                        {log.status.charAt(0).toUpperCase() + log.status.slice(1)}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {log.sent_at ? new Date(log.sent_at).toLocaleString() : "Not sent"}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>

        {filteredLogs.length > 0 && (
          <div className="flex items-center justify-between pt-4">
            <p className="text-sm text-muted-foreground">
              Showing {filteredLogs.length} of {smsLogs.length} SMS logs
            </p>
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span>Sent: {filteredLogs.filter((log) => log.status === "sent").length}</span>
              <span>Failed: {filteredLogs.filter((log) => log.status === "failed").length}</span>
              <span>Pending: {filteredLogs.filter((log) => log.status === "pending").length}</span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
