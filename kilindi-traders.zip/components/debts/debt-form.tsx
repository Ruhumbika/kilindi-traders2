"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { CreateDebtData, Debt, Trader } from "@/lib/types"

interface DebtFormProps {
  debt?: Debt
  onSubmit: (data: CreateDebtData) => Promise<void>
  onCancel: () => void
  isLoading?: boolean
}

export function DebtForm({ debt, onSubmit, onCancel, isLoading }: DebtFormProps) {
  const [traders, setTraders] = useState<Trader[]>([])
  const [formData, setFormData] = useState<CreateDebtData>({
    trader_id: debt?.trader_id || 0,
    amount: debt?.amount || 0,
    description: debt?.description || "",
    due_date: debt?.due_date || "",
  })

  useEffect(() => {
    loadTraders()
  }, [])

  const loadTraders = async () => {
    try {
      const response = await fetch("/api/traders")
      if (response.ok) {
        const data = await response.json()
        setTraders(data)
      }
    } catch (error) {
      console.error("Failed to load traders:", error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    await onSubmit(formData)
  }

  const handleChange = (field: keyof CreateDebtData, value: string | number) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>{debt ? "Edit Debt" : "Add New Debt"}</CardTitle>
        <CardDescription>{debt ? "Update debt information" : "Record a new debt for a trader"}</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="trader_id">Trader *</Label>
              <Select
                value={formData.trader_id.toString()}
                onValueChange={(value) => handleChange("trader_id", Number.parseInt(value))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a trader" />
                </SelectTrigger>
                <SelectContent>
                  {traders.map((trader) => (
                    <SelectItem key={trader.id} value={trader.id.toString()}>
                      {trader.business_name} - {trader.owner_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="amount">Amount (TSh) *</Label>
              <Input
                id="amount"
                type="number"
                min="0"
                step="0.01"
                value={formData.amount}
                onChange={(e) => handleChange("amount", Number.parseFloat(e.target.value) || 0)}
                placeholder="Enter debt amount"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="due_date">Due Date</Label>
              <Input
                id="due_date"
                type="date"
                value={formData.due_date}
                onChange={(e) => handleChange("due_date", e.target.value)}
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => handleChange("description", e.target.value)}
                placeholder="Enter debt description or reason"
                rows={3}
              />
            </div>
          </div>

          <div className="flex gap-4 pt-4">
            <Button type="submit" disabled={isLoading} className="flex-1">
              {isLoading ? "Saving..." : debt ? "Update Debt" : "Add Debt"}
            </Button>
            <Button type="button" variant="outline" onClick={onCancel} className="flex-1 bg-transparent">
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
