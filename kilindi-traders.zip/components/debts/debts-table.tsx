"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, MoreHorizontal, Edit, CreditCard, AlertTriangle, CheckCircle, Clock } from "lucide-react"
import type { Debt } from "@/lib/types"

interface DebtsTableProps {
  debts: Debt[]
  onEdit: (debt: Debt) => void
  onRecordPayment: (debt: Debt) => void
  onUpdateStatus: (debt: Debt, status: Debt["status"]) => void
}

export function DebtsTable({ debts, onEdit, onRecordPayment, onUpdateStatus }: DebtsTableProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")

  const filteredDebts = debts.filter((debt) => {
    const matchesSearch =
      debt.trader?.business_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      debt.trader?.owner_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      debt.description?.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === "all" || debt.status === statusFilter

    return matchesSearch && matchesStatus
  })

  const getStatusIcon = (status: Debt["status"]) => {
    switch (status) {
      case "paid":
        return <CheckCircle className="h-3 w-3" />
      case "overdue":
        return <AlertTriangle className="h-3 w-3" />
      default:
        return <Clock className="h-3 w-3" />
    }
  }

  const getStatusVariant = (status: Debt["status"]) => {
    switch (status) {
      case "paid":
        return "default" as const
      case "overdue":
        return "destructive" as const
      default:
        return "secondary" as const
    }
  }

  const isOverdue = (debt: Debt) => {
    if (!debt.due_date) return false
    return new Date(debt.due_date) < new Date() && debt.status === "pending"
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Debt Collection</CardTitle>
            <CardDescription>Manage trader debts and payment tracking</CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="paid">Paid</SelectItem>
                <SelectItem value="overdue">Overdue</SelectItem>
              </SelectContent>
            </Select>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search debts..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-64"
              />
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Trader</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Due Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Created</TableHead>
                <TableHead className="w-[70px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredDebts.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                    {searchTerm || statusFilter !== "all"
                      ? "No debts found matching your criteria."
                      : "No debts recorded yet."}
                  </TableCell>
                </TableRow>
              ) : (
                filteredDebts.map((debt) => (
                  <TableRow key={debt.id} className={isOverdue(debt) ? "bg-red-50 dark:bg-red-950/20" : ""}>
                    <TableCell>
                      <div>
                        <p className="font-medium">{debt.trader?.business_name || "Unknown Business"}</p>
                        <p className="text-sm text-muted-foreground">{debt.trader?.owner_name}</p>
                      </div>
                    </TableCell>
                    <TableCell className="font-mono font-medium">TSh {debt.amount.toLocaleString()}</TableCell>
                    <TableCell className="max-w-xs">
                      <p className="truncate" title={debt.description}>
                        {debt.description || "No description"}
                      </p>
                    </TableCell>
                    <TableCell>
                      {debt.due_date ? (
                        <div className={`text-sm ${isOverdue(debt) ? "text-red-600 font-medium" : ""}`}>
                          {new Date(debt.due_date).toLocaleDateString()}
                          {isOverdue(debt) && <div className="text-xs text-red-500">Overdue</div>}
                        </div>
                      ) : (
                        <span className="text-muted-foreground">No due date</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge variant={getStatusVariant(debt.status)} className="flex items-center gap-1 w-fit">
                        {getStatusIcon(debt.status)}
                        {debt.status.charAt(0).toUpperCase() + debt.status.slice(1)}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {new Date(debt.created_at).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => onEdit(debt)}>
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          {debt.status !== "paid" && (
                            <DropdownMenuItem onClick={() => onRecordPayment(debt)}>
                              <CreditCard className="h-4 w-4 mr-2" />
                              Record Payment
                            </DropdownMenuItem>
                          )}
                          {debt.status === "pending" && isOverdue(debt) && (
                            <DropdownMenuItem onClick={() => onUpdateStatus(debt, "overdue")}>
                              <AlertTriangle className="h-4 w-4 mr-2" />
                              Mark Overdue
                            </DropdownMenuItem>
                          )}
                          {debt.status === "overdue" && (
                            <DropdownMenuItem onClick={() => onUpdateStatus(debt, "pending")}>
                              <Clock className="h-4 w-4 mr-2" />
                              Mark Pending
                            </DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>

        {filteredDebts.length > 0 && (
          <div className="flex items-center justify-between pt-4">
            <p className="text-sm text-muted-foreground">
              Showing {filteredDebts.length} of {debts.length} debts
            </p>
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span>Total: TSh {filteredDebts.reduce((sum, debt) => sum + debt.amount, 0).toLocaleString()}</span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
