"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { TrendingUp, DollarSign, CreditCard, FileText } from "lucide-react"

interface FinancialReportProps {
  data: {
    period: { startDate: string; endDate: string }
    summary: {
      totalRevenue: number
      debtPayments: number
      licensePayments: number
      outstandingDebts: number
      totalPayments: number
    }
    monthlyData: Array<{
      month: string
      revenue: number
      debtPayments: number
      licensePayments: number
    }>
    paymentMethods: Record<string, number>
  }
}

export function FinancialReport({ data }: FinancialReportProps) {
  const { summary, monthlyData, paymentMethods } = data

  const formatCurrency = (amount: number) => `TSh ${amount.toLocaleString()}`
  const formatMonth = (month: string) =>
    new Date(month + "-01").toLocaleDateString("en-US", { month: "long", year: "numeric" })

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{formatCurrency(summary.totalRevenue)}</div>
            <p className="text-xs text-muted-foreground">{summary.totalPayments} payments received</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Debt Collections</CardTitle>
            <CreditCard className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{formatCurrency(summary.debtPayments)}</div>
            <p className="text-xs text-muted-foreground">
              {((summary.debtPayments / summary.totalRevenue) * 100).toFixed(1)}% of total revenue
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">License Fees</CardTitle>
            <FileText className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{formatCurrency(summary.licensePayments)}</div>
            <p className="text-xs text-muted-foreground">
              {((summary.licensePayments / summary.totalRevenue) * 100).toFixed(1)}% of total revenue
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Outstanding Debts</CardTitle>
            <DollarSign className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{formatCurrency(summary.outstandingDebts)}</div>
            <p className="text-xs text-muted-foreground">Pending collection</p>
          </CardContent>
        </Card>
      </div>

      {/* Monthly Revenue Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Monthly Revenue Breakdown</CardTitle>
          <CardDescription>Revenue trends over the selected period</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Month</TableHead>
                  <TableHead>Total Revenue</TableHead>
                  <TableHead>Debt Payments</TableHead>
                  <TableHead>License Payments</TableHead>
                  <TableHead>Growth</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {monthlyData.map((month, index) => {
                  const previousMonth = index > 0 ? monthlyData[index - 1] : null
                  const growth = previousMonth
                    ? ((month.revenue - previousMonth.revenue) / previousMonth.revenue) * 100
                    : 0

                  return (
                    <TableRow key={month.month}>
                      <TableCell className="font-medium">{formatMonth(month.month)}</TableCell>
                      <TableCell className="font-mono">{formatCurrency(month.revenue)}</TableCell>
                      <TableCell className="font-mono">{formatCurrency(month.debtPayments)}</TableCell>
                      <TableCell className="font-mono">{formatCurrency(month.licensePayments)}</TableCell>
                      <TableCell>
                        {index > 0 && (
                          <Badge variant={growth >= 0 ? "default" : "destructive"}>
                            {growth >= 0 ? "+" : ""}
                            {growth.toFixed(1)}%
                          </Badge>
                        )}
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Payment Methods Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Payment Methods</CardTitle>
          <CardDescription>Revenue breakdown by payment method</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {Object.entries(paymentMethods).map(([method, amount]) => {
              const percentage = (amount / summary.totalRevenue) * 100
              return (
                <div key={method} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">{method.replace("_", " ").replace(/\b\w/g, (l) => l.toUpperCase())}</Badge>
                  </div>
                  <div className="text-right">
                    <div className="font-mono font-medium">{formatCurrency(amount)}</div>
                    <div className="text-xs text-muted-foreground">{percentage.toFixed(1)}%</div>
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
