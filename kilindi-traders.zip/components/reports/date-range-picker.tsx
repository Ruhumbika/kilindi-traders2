"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar, Download } from "lucide-react"

interface DateRangePickerProps {
  onDateRangeChange: (startDate: string, endDate: string) => void
  onExport?: (format: "pdf" | "excel") => void
  isLoading?: boolean
}

export function DateRangePicker({ onDateRangeChange, onExport, isLoading }: DateRangePickerProps) {
  const [startDate, setStartDate] = useState(() => {
    const date = new Date()
    date.setMonth(date.getMonth() - 3) // Default to last 3 months
    return date.toISOString().split("T")[0]
  })

  const [endDate, setEndDate] = useState(() => {
    return new Date().toISOString().split("T")[0]
  })

  const [preset, setPreset] = useState("custom")

  const handlePresetChange = (value: string) => {
    setPreset(value)
    const today = new Date()
    let start: Date
    const end: Date = today

    switch (value) {
      case "today":
        start = today
        break
      case "week":
        start = new Date(today)
        start.setDate(today.getDate() - 7)
        break
      case "month":
        start = new Date(today)
        start.setMonth(today.getMonth() - 1)
        break
      case "quarter":
        start = new Date(today)
        start.setMonth(today.getMonth() - 3)
        break
      case "year":
        start = new Date(today)
        start.setFullYear(today.getFullYear() - 1)
        break
      default:
        return // Custom - don't change dates
    }

    const startStr = start.toISOString().split("T")[0]
    const endStr = end.toISOString().split("T")[0]

    setStartDate(startStr)
    setEndDate(endStr)
    onDateRangeChange(startStr, endStr)
  }

  const handleDateChange = () => {
    onDateRangeChange(startDate, endDate)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="h-5 w-5" />
          Report Period
        </CardTitle>
        <CardDescription>Select the date range for your report</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-2">
            <Label>Quick Select</Label>
            <Select value={preset} onValueChange={handlePresetChange}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="week">Last 7 Days</SelectItem>
                <SelectItem value="month">Last Month</SelectItem>
                <SelectItem value="quarter">Last 3 Months</SelectItem>
                <SelectItem value="year">Last Year</SelectItem>
                <SelectItem value="custom">Custom Range</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="start-date">Start Date</Label>
            <Input
              id="start-date"
              type="date"
              value={startDate}
              onChange={(e) => {
                setStartDate(e.target.value)
                setPreset("custom")
              }}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="end-date">End Date</Label>
            <Input
              id="end-date"
              type="date"
              value={endDate}
              onChange={(e) => {
                setEndDate(e.target.value)
                setPreset("custom")
              }}
            />
          </div>
        </div>

        <div className="flex items-center gap-2 pt-2">
          <Button onClick={handleDateChange} disabled={isLoading}>
            {isLoading ? "Generating..." : "Generate Report"}
          </Button>

          {onExport && (
            <>
              <Button variant="outline" onClick={() => onExport("pdf")} disabled={isLoading}>
                <Download className="h-4 w-4 mr-2" />
                Export PDF
              </Button>
              <Button variant="outline" onClick={() => onExport("excel")} disabled={isLoading}>
                <Download className="h-4 w-4 mr-2" />
                Export Excel
              </Button>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
