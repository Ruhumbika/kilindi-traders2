"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Loader2, CreditCard, Smartphone, Building, Banknote } from "lucide-react"
import type { Trader } from "@/lib/types"

interface PaymentFormProps {
  trader?: Trader
  debtId?: number
  licenseId?: number
  amount?: number
  description?: string
  onSuccess?: (result: any) => void
  onCancel?: () => void
}

export function PaymentForm({
  trader,
  debtId,
  licenseId,
  amount: initialAmount,
  description: initialDescription,
  onSuccess,
  onCancel,
}: PaymentFormProps) {
  const [formData, setFormData] = useState({
    amount: initialAmount || 0,
    payment_method: "",
    phone_number: trader?.phone || "",
    description: initialDescription || "",
    trader_id: trader?.id || 0,
  })
  const [isProcessing, setIsProcessing] = useState(false)
  const [result, setResult] = useState<any>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsProcessing(true)

    try {
      const paymentRequest = {
        ...formData,
        debt_id: debtId,
        license_id: licenseId,
      }

      const response = await fetch("/api/payments/process", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(paymentRequest),
      })

      const data = await response.json()
      setResult(data)

      if (data.success && onSuccess) {
        onSuccess(data)
      }
    } catch (error) {
      console.error("Payment processing failed:", error)
      setResult({
        success: false,
        message: "Payment processing failed. Please try again.",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const getPaymentMethodIcon = (method: string) => {
    switch (method) {
      case "mpesa":
      case "airtel_money":
        return <Smartphone className="h-4 w-4" />
      case "bank":
        return <Building className="h-4 w-4" />
      case "cash":
        return <Banknote className="h-4 w-4" />
      default:
        return <CreditCard className="h-4 w-4" />
    }
  }

  if (result) {
    return (
      <Card className="w-full max-w-md mx-auto">
        <CardHeader>
          <CardTitle className={result.success ? "text-green-600" : "text-red-600"}>
            {result.success ? "Payment Successful" : "Payment Failed"}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">{result.message}</p>

          {result.success && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Transaction ID:</span>
                <span className="font-mono">{result.transaction_id}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Amount:</span>
                <span className="font-semibold">TSh {formData.amount.toLocaleString()}</span>
              </div>
              {result.receipt_url && (
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full bg-transparent"
                  onClick={() => window.open(result.receipt_url, "_blank")}
                >
                  View Receipt
                </Button>
              )}
            </div>
          )}

          <div className="flex gap-2">
            {result.success && onSuccess && (
              <Button onClick={() => onSuccess(result)} className="flex-1">
                Continue
              </Button>
            )}
            {onCancel && (
              <Button variant="outline" onClick={onCancel} className="flex-1 bg-transparent">
                {result.success ? "Close" : "Try Again"}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Process Payment</CardTitle>
        <CardDescription>{trader && `Payment for ${trader.business_name}`}</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="amount">Amount (TSh)</Label>
            <Input
              id="amount"
              type="number"
              value={formData.amount}
              onChange={(e) => setFormData({ ...formData, amount: Number(e.target.value) })}
              required
              min="1"
              disabled={!!initialAmount}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="payment_method">Payment Method</Label>
            <Select
              value={formData.payment_method}
              onValueChange={(value) => setFormData({ ...formData, payment_method: value })}
              required
            >
              <SelectTrigger>
                <SelectValue placeholder="Select payment method" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="mpesa">
                  <div className="flex items-center gap-2">
                    <Smartphone className="h-4 w-4" />
                    M-Pesa
                  </div>
                </SelectItem>
                <SelectItem value="airtel_money">
                  <div className="flex items-center gap-2">
                    <Smartphone className="h-4 w-4" />
                    Airtel Money
                  </div>
                </SelectItem>
                <SelectItem value="bank">
                  <div className="flex items-center gap-2">
                    <Building className="h-4 w-4" />
                    Bank Transfer
                  </div>
                </SelectItem>
                <SelectItem value="cash">
                  <div className="flex items-center gap-2">
                    <Banknote className="h-4 w-4" />
                    Cash
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          {(formData.payment_method === "mpesa" || formData.payment_method === "airtel_money") && (
            <div className="space-y-2">
              <Label htmlFor="phone_number">Phone Number</Label>
              <Input
                id="phone_number"
                type="tel"
                value={formData.phone_number}
                onChange={(e) => setFormData({ ...formData, phone_number: e.target.value })}
                placeholder="255XXXXXXXXX"
                required
              />
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Payment description..."
              rows={3}
            />
          </div>

          <div className="flex gap-2">
            <Button type="submit" disabled={isProcessing} className="flex-1">
              {isProcessing ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  {getPaymentMethodIcon(formData.payment_method)}
                  <span className="ml-2">Process Payment</span>
                </>
              )}
            </Button>
            {onCancel && (
              <Button type="button" variant="outline" onClick={onCancel}>
                Cancel
              </Button>
            )}
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
