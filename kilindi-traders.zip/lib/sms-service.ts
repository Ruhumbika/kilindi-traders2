// SMS service integration for AfricasTalking and other providers
// This is a mock implementation - replace with actual SMS gateway integration

export interface SmsConfig {
  provider: "africas_talking" | "twilio" | "mock"
  apiKey?: string
  username?: string
  senderId?: string
}

export interface SmsMessage {
  to: string
  message: string
  type?: "debt_reminder" | "license_expiry" | "payment_confirmation" | "manual"
}

export interface SmsResponse {
  success: boolean
  messageId?: string
  error?: string
  cost?: number
}

class SmsService {
  private config: SmsConfig

  constructor(config: SmsConfig) {
    this.config = config
  }

  async sendSms(message: SmsMessage): Promise<SmsResponse> {
    try {
      switch (this.config.provider) {
        case "africas_talking":
          return await this.sendViaAfricasTalking(message)
        case "twilio":
          return await this.sendViaTwilio(message)
        default:
          return await this.sendViaMock(message)
      }
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      }
    }
  }

  private async sendViaAfricasTalking(message: SmsMessage): Promise<SmsResponse> {
    // Mock implementation - replace with actual AfricasTalking API call
    console.log("[SMS] AfricasTalking:", message)

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Mock success response
    return {
      success: true,
      messageId: `AT_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      cost: 0.05, // Mock cost in USD
    }
  }

  private async sendViaTwilio(message: SmsMessage): Promise<SmsResponse> {
    // Mock implementation - replace with actual Twilio API call
    console.log("[SMS] Twilio:", message)

    await new Promise((resolve) => setTimeout(resolve, 800))

    return {
      success: true,
      messageId: `TW_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      cost: 0.08,
    }
  }

  private async sendViaMock(message: SmsMessage): Promise<SmsResponse> {
    console.log("[SMS] Mock Provider:", message)

    // Simulate random failures for testing
    const shouldFail = Math.random() < 0.1 // 10% failure rate

    await new Promise((resolve) => setTimeout(resolve, 500))

    if (shouldFail) {
      return {
        success: false,
        error: "Mock SMS delivery failed",
      }
    }

    return {
      success: true,
      messageId: `MOCK_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      cost: 0.03,
    }
  }

  async sendBulkSms(messages: SmsMessage[]): Promise<SmsResponse[]> {
    const results: SmsResponse[] = []

    for (const message of messages) {
      const result = await this.sendSms(message)
      results.push(result)

      // Add small delay between messages to avoid rate limiting
      await new Promise((resolve) => setTimeout(resolve, 100))
    }

    return results
  }
}

// SMS Templates
export const SMS_TEMPLATES = {
  debt_reminder: (traderName: string, businessName: string, amount: number, dueDate?: string) =>
    `Dear ${traderName}, your business ${businessName} has an outstanding debt of TSh ${amount.toLocaleString()}${
      dueDate ? ` due on ${new Date(dueDate).toLocaleDateString()}` : ""
    }. Please settle this amount at Kilindi District Office. Thank you.`,

  license_expiry: (
    traderName: string,
    businessName: string,
    licenseType: string,
    expiryDate: string,
    daysLeft: number,
  ) =>
    `Dear ${traderName}, your ${licenseType} for ${businessName} expires on ${new Date(expiryDate).toLocaleDateString()} (${daysLeft} days). Please renew at Kilindi District Office to avoid penalties.`,

  payment_confirmation: (traderName: string, amount: number, reference?: string) =>
    `Dear ${traderName}, we confirm receipt of your payment of TSh ${amount.toLocaleString()}${
      reference ? ` (Ref: ${reference})` : ""
    }. Thank you for your prompt payment. - Kilindi District Office`,

  license_renewal_reminder: (traderName: string, businessName: string, licenseType: string, penalty: number) =>
    `Dear ${traderName}, your ${licenseType} for ${businessName} has expired. Renew now to avoid additional penalties. Current penalty: TSh ${penalty.toLocaleString()}. Visit Kilindi District Office.`,
}

// Initialize SMS service
export const smsService = new SmsService({
  provider: "mock", // Change to "africas_talking" in production
  apiKey: process.env.AFRICAS_TALKING_API_KEY,
  username: process.env.AFRICAS_TALKING_USERNAME,
  senderId: "KILINDI",
})
