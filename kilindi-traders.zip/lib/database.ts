// Database utility functions for the Kilindi District Traders system
// Note: In a real implementation, you would use a proper database connection
// This is a mock implementation for demonstration purposes

import type { Trader, Debt, License, Payment, SmsLog, DashboardStats } from "./types"

// Mock database - In production, replace with actual database queries
const mockTraders: Trader[] = []
let mockDebts: Debt[] = []
let mockLicenses: License[] = []
let mockPayments: Payment[] = []
let mockSmsLogs: SmsLog[] = []

// Trader operations
export async function createTrader(data: Omit<Trader, "id" | "created_at" | "updated_at">): Promise<Trader> {
  const trader: Trader = {
    ...data,
    id: mockTraders.length + 1,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  }
  mockTraders.push(trader)
  return trader
}

export async function getTraders(): Promise<Trader[]> {
  return mockTraders
}

export async function getTraderById(id: number): Promise<Trader | null> {
  return mockTraders.find((t) => t.id === id) || null
}

export async function updateTrader(id: number, data: Partial<Trader>): Promise<Trader | null> {
  const index = mockTraders.findIndex((t) => t.id === id)
  if (index === -1) return null

  mockTraders[index] = {
    ...mockTraders[index],
    ...data,
    updated_at: new Date().toISOString(),
  }
  return mockTraders[index]
}

export async function deleteTrader(id: number): Promise<boolean> {
  const index = mockTraders.findIndex((t) => t.id === id)
  if (index === -1) return false

  mockTraders.splice(index, 1)
  // Also remove related records
  mockDebts = mockDebts.filter((d) => d.trader_id !== id)
  mockLicenses = mockLicenses.filter((l) => l.trader_id !== id)
  mockPayments = mockPayments.filter((p) => p.trader_id !== id)
  mockSmsLogs = mockSmsLogs.filter((s) => s.trader_id !== id)

  return true
}

// Debt operations
export async function createDebt(data: Omit<Debt, "id" | "created_at" | "updated_at">): Promise<Debt> {
  const debt: Debt = {
    ...data,
    id: mockDebts.length + 1,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  }
  mockDebts.push(debt)
  return debt
}

export async function getDebts(): Promise<Debt[]> {
  return mockDebts.map((debt) => ({
    ...debt,
    trader: mockTraders.find((t) => t.id === debt.trader_id),
  }))
}

export async function getDebtsByTraderId(traderId: number): Promise<Debt[]> {
  return mockDebts.filter((d) => d.trader_id === traderId)
}

export async function updateDebtStatus(id: number, status: Debt["status"]): Promise<Debt | null> {
  const index = mockDebts.findIndex((d) => d.id === id)
  if (index === -1) return null

  mockDebts[index] = {
    ...mockDebts[index],
    status,
    updated_at: new Date().toISOString(),
  }
  return mockDebts[index]
}

// License operations
export async function createLicense(data: Omit<License, "id" | "created_at" | "updated_at">): Promise<License> {
  const license: License = {
    ...data,
    id: mockLicenses.length + 1,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  }
  mockLicenses.push(license)
  return license
}

export async function getLicenses(): Promise<License[]> {
  return mockLicenses.map((license) => ({
    ...license,
    trader: mockTraders.find((t) => t.id === license.trader_id),
  }))
}

export async function getExpiringLicenses(days = 30): Promise<License[]> {
  const futureDate = new Date()
  futureDate.setDate(futureDate.getDate() + days)

  return mockLicenses
    .filter((license) => {
      if (!license.expiry_date) return false
      const expiryDate = new Date(license.expiry_date)
      return expiryDate <= futureDate && license.status === "active"
    })
    .map((license) => ({
      ...license,
      trader: mockTraders.find((t) => t.id === license.trader_id),
    }))
}

// Payment operations
export async function createPayment(data: Omit<Payment, "id" | "created_at">): Promise<Payment> {
  const payment: Payment = {
    ...data,
    id: mockPayments.length + 1,
    created_at: new Date().toISOString(),
  }
  mockPayments.push(payment)

  // Update debt status if this is a debt payment
  if (payment.debt_id) {
    await updateDebtStatus(payment.debt_id, "paid")
  }

  return payment
}

export async function getPayments(): Promise<Payment[]> {
  return mockPayments.map((payment) => ({
    ...payment,
    trader: mockTraders.find((t) => t.id === payment.trader_id),
    debt: payment.debt_id ? mockDebts.find((d) => d.id === payment.debt_id) : undefined,
    license: payment.license_id ? mockLicenses.find((l) => l.id === payment.license_id) : undefined,
  }))
}

// SMS operations
export async function createSmsLog(data: Omit<SmsLog, "id" | "created_at">): Promise<SmsLog> {
  const smsLog: SmsLog = {
    ...data,
    id: mockSmsLogs.length + 1,
    created_at: new Date().toISOString(),
  }
  mockSmsLogs.push(smsLog)
  return smsLog
}

export async function getSmsLogs(): Promise<SmsLog[]> {
  return mockSmsLogs.map((log) => ({
    ...log,
    trader: mockTraders.find((t) => t.id === log.trader_id),
  }))
}

// Dashboard statistics
export async function getDashboardStats(): Promise<DashboardStats> {
  const totalDebts = mockDebts.length
  const totalDebtAmount = mockDebts.reduce((sum, debt) => sum + debt.amount, 0)
  const paidDebts = mockDebts.filter((d) => d.status === "paid")
  const paidDebtAmount = paidDebts.reduce((sum, debt) => sum + debt.amount, 0)
  const pendingDebtAmount = mockDebts.filter((d) => d.status === "pending").reduce((sum, debt) => sum + debt.amount, 0)
  const overdueDebtAmount = mockDebts.filter((d) => d.status === "overdue").reduce((sum, debt) => sum + debt.amount, 0)

  const expiringLicenses = await getExpiringLicenses(30)
  const totalRevenue = mockPayments.reduce((sum, payment) => sum + payment.amount, 0)

  return {
    total_traders: mockTraders.length,
    total_debts: totalDebts,
    total_debt_amount: totalDebtAmount,
    paid_debt_amount: paidDebtAmount,
    pending_debt_amount: pendingDebtAmount,
    overdue_debt_amount: overdueDebtAmount,
    expiring_licenses: expiringLicenses.length,
    total_revenue: totalRevenue,
  }
}
