export interface PaymentRequest {
  amount: number
  phone_number?: string
  payment_method: "mpesa" | "airtel_money" | "bank" | "cash"
  reference: string
  description: string
  trader_id: number
  debt_id?: number
  license_id?: number
}

export interface PaymentResponse {
  success: boolean
  transaction_id: string
  reference: string
  message: string
  receipt_url?: string
}

export class PaymentService {
  // M-Pesa STK Push simulation
  static async processMpesaPayment(request: PaymentRequest): Promise<PaymentResponse> {
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Mock successful payment (90% success rate)
    const success = Math.random() > 0.1

    if (success) {
      return {
        success: true,
        transaction_id: `MP${Date.now()}${Math.random().toString(36).substr(2, 5).toUpperCase()}`,
        reference: request.reference,
        message: "Payment processed successfully via M-Pesa",
        receipt_url: `/api/receipts/${request.reference}`,
      }
    } else {
      return {
        success: false,
        transaction_id: "",
        reference: request.reference,
        message: "Payment failed. Please try again or contact support.",
      }
    }
  }

  // Airtel Money payment simulation
  static async processAirtelPayment(request: PaymentRequest): Promise<PaymentResponse> {
    await new Promise((resolve) => setTimeout(resolve, 1500))

    const success = Math.random() > 0.15

    if (success) {
      return {
        success: true,
        transaction_id: `AM${Date.now()}${Math.random().toString(36).substr(2, 5).toUpperCase()}`,
        reference: request.reference,
        message: "Payment processed successfully via Airtel Money",
        receipt_url: `/api/receipts/${request.reference}`,
      }
    } else {
      return {
        success: false,
        transaction_id: "",
        reference: request.reference,
        message: "Airtel Money payment failed. Please check your balance and try again.",
      }
    }
  }

  // Bank transfer processing
  static async processBankPayment(request: PaymentRequest): Promise<PaymentResponse> {
    await new Promise((resolve) => setTimeout(resolve, 1000))

    return {
      success: true,
      transaction_id: `BT${Date.now()}${Math.random().toString(36).substr(2, 5).toUpperCase()}`,
      reference: request.reference,
      message: "Bank transfer recorded. Verification pending.",
      receipt_url: `/api/receipts/${request.reference}`,
    }
  }

  // Cash payment processing
  static async processCashPayment(request: PaymentRequest): Promise<PaymentResponse> {
    return {
      success: true,
      transaction_id: `CS${Date.now()}${Math.random().toString(36).substr(2, 5).toUpperCase()}`,
      reference: request.reference,
      message: "Cash payment recorded successfully",
      receipt_url: `/api/receipts/${request.reference}`,
    }
  }

  // Main payment processor
  static async processPayment(request: PaymentRequest): Promise<PaymentResponse> {
    switch (request.payment_method) {
      case "mpesa":
        return this.processMpesaPayment(request)
      case "airtel_money":
        return this.processAirtelPayment(request)
      case "bank":
        return this.processBankPayment(request)
      case "cash":
        return this.processCashPayment(request)
      default:
        return {
          success: false,
          transaction_id: "",
          reference: request.reference,
          message: "Unsupported payment method",
        }
    }
  }

  // Generate payment reference
  static generateReference(type: "debt" | "license", id: number): string {
    const prefix = type === "debt" ? "DBT" : "LIC"
    return `${prefix}${id}${Date.now().toString().slice(-6)}`
  }
}
