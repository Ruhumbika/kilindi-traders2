// TypeScript types for the Kilindi District Traders system

export interface Trader {
  id: number
  business_name: string
  owner_name: string
  phone_number: string
  business_location?: string
  business_type?: string
  license_number?: string
  license_expiry_date?: string
  created_at: string
  updated_at: string
}

export interface Debt {
  id: number
  trader_id: number
  amount: number
  description?: string
  due_date?: string
  status: "pending" | "paid" | "overdue"
  created_at: string
  updated_at: string
  trader?: Trader // For joined queries
}

export interface License {
  id: number
  trader_id: number
  license_type: string
  fee_amount: number
  issue_date?: string
  expiry_date?: string
  status: "active" | "expired" | "renewed"
  penalty_amount: number
  created_at: string
  updated_at: string
  trader?: Trader // For joined queries
}

export interface Payment {
  id: number
  trader_id: number
  debt_id?: number
  license_id?: number
  amount: number
  payment_method?: "mpesa" | "airtel_money" | "bank" | "cash"
  transaction_reference?: string
  payment_date: string
  notes?: string
  created_at: string
  trader?: Trader // For joined queries
  debt?: Debt // For joined queries
  license?: License // For joined queries
}

export interface SmsLog {
  id: number
  trader_id: number
  phone_number: string
  message: string
  sms_type?: "debt_reminder" | "license_expiry" | "payment_confirmation"
  status: "pending" | "sent" | "failed"
  sent_at?: string
  created_at: string
  trader?: Trader // For joined queries
}

// Form types for creating/updating records
export interface CreateTraderData {
  business_name: string
  owner_name: string
  phone_number: string
  business_location?: string
  business_type?: string
  license_number?: string
  license_expiry_date?: string
}

export interface CreateDebtData {
  trader_id: number
  amount: number
  description?: string
  due_date?: string
}

export interface CreateLicenseData {
  trader_id: number
  license_type: string
  fee_amount: number
  issue_date?: string
  expiry_date?: string
}

export interface CreatePaymentData {
  trader_id: number
  debt_id?: number
  license_id?: number
  amount: number
  payment_method?: "mpesa" | "airtel_money" | "bank" | "cash"
  transaction_reference?: string
  notes?: string
}

// Dashboard statistics type
export interface DashboardStats {
  total_traders: number
  total_debts: number
  total_debt_amount: number
  paid_debt_amount: number
  pending_debt_amount: number
  overdue_debt_amount: number
  expiring_licenses: number
  total_revenue: number
}

// Excel import type for bulk trader upload
export interface ExcelTraderData {
  business_name: string
  owner_name: string
  phone_number: string
  business_location?: string
  business_type?: string
  license_number?: string
  license_expiry_date?: string
}
